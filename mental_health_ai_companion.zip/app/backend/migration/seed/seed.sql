-- Seed data for emotion/need/action schema

-- Emotions
INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('buon', 'Buồn', 'Cảm giác buồn bã, mất năng lượng', -0.7, 0.6, 'medium', 'đồng cảm', 'buon')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('lo_lang', 'Lo lắng', 'Cảm giác lo âu, căng thẳng', -0.5, 0.7, 'medium', 'trấn an', 'lo_lang')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('met_moi', 'Mệt mỏi', 'Kiệt sức, thiếu động lực', -0.6, 0.6, 'low', 'khích lệ nhẹ nhàng', 'met_moi')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('vui', 'Vui', 'Tích cực, hạnh phúc', 0.8, 0.6, 'low', 'tích cực', 'vui')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('co_dong_luc', 'Có động lực', 'Cảm thấy có mục tiêu và sẵn sàng hành động', 0.7, 0.8, 'low', 'khích lệ', 'co_dong_luc')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('tuc_gian', 'Tức giận', 'Cảm giác bực bội, muốn phản kháng',-0.8, 0.8, 'high', 'bình tĩnh', 'tuc_gian')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('toi_loi', 'Tội lỗi', 'Cảm giác hối hận vì đã làm điều sai',-0.6, 0.6, 'medium', 'tha thứ, cảm thông', 'toi_loi')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('boi_roi', 'Bối rối', 'Không rõ ràng, lẫn lộn trong suy nghĩ hoặc cảm xúc',-0.3, 0.5, 'low', 'giải thích, làm rõ', 'boi_roi')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('so_hai', 'Sợ hãi', 'Cảm giác sợ hãi, bất an, tránh né nguy hiểm',-0.7, 0.8, 'high', 'trấn an, đảm bảo an toàn', 'so_hai')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO emotions (slug, name, description, valence, intensity, risk_level, default_tone, category)
VALUES
  ('trung_lap', 'Trung lập', 'Trạng thái bình thường, không cảm xúc rõ ràng',0.0, 0.4, 'low', 'tự nhiên', 'trung_lap')
ON CONFLICT (slug) DO NOTHING;


-- Emotion keywords
CREATE TYPE text_weight AS (kw text, wt numeric);

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('buồn',0.75),
    ROW('buồn bã', 0.82),
    ROW('buồn nhiều', 0.85),
    ROW('buồn rầu', 0.83),
    ROW('buồn thắt lòng', 0.88),
    ROW('buồn man mác', 0.78),
    ROW('buồn tê tái', 0.87),
    ROW('buồn da diết', 0.88),
    ROW('buồn vô cớ', 0.75),
    ROW('buồn thẫn thờ', 0.8),
    ROW('chán nản',0.75),
    ROW('chán', 0.7),
    ROW('buồn quá', 0.95),
    ROW('buồn thật', 0.9),
    ROW('đau lòng',0.95),
    ROW('muốn khóc',1.0),
    ROW('tổn thương',0.9),
    ROW('hụt hẫng',0.75),
    ROW('mất mát',0.9),
    ROW('tuyệt vọng',0.95),
    ROW('mất năng lượng',0.67),
    ROW('tủi thân',0.8),
    ROW('sad',0.75),
    ROW('depressed',0.9),
    ROW('tụt mood',0.7),
    ROW('nản',0.6),
    ROW('phiền lòng',0.7),
    ROW('buồn buồn',0.7),
    ROW('hơi buồn',0.65),
    ROW('cảm thấy buồn',0.7),
    ROW('có chút buồn',0.65),
    ROW('buồn lòng',0.75),
    ROW('buồn chút',0.65),
    ROW('buồn một chút',0.65),
    ROW('chẳng vui',0.6),
    ROW('không ổn',0.6),
    ROW('không vui',0.65),
    ROW('thất vọng tẹo',0.7),
    ROW('thất vọng nhẹ',0.7),
    ROW('chán đời',0.7),
    ROW('lowkey sad',0.7),
    ROW('down mood', 0.8),
    ROW('tụt cảm xúc', 0.75),
    ROW('cô đơn', 0.85),
    ROW('đau khổ', 0.92),
    ROW('tan nát', 0.93),
    ROW('suy sụp', 0.94),
    ROW('gục ngã', 0.9),
    ROW('cô độc', 0.9),
    ROW('trống rỗng', 0.9),
    ROW('một mình', 0.7),
    ROW('nặng lòng', 0.77),
    ROW('nỗi buồn đè nặng', 0.85),
    ROW('lòng nặng trĩu', 0.85),
    ROW('tim chùng xuống', 0.82),
    ROW('lòng trống trải', 0.8),
    ROW('lòng nặng trĩu', 0.85),
    ROW('lạc lõng', 0.88),
    ROW('nhói lòng', 0.85),
    ROW('buồn nhẹ', 0.65),
    ROW('buồn sâu', 0.92),
    ROW('buồn dai dẳng', 0.88),
    ROW('mất động lực', 0.8),
    ROW('mất niềm tin', 0.87),
    ROW('mất phương hướng', 0.8),
    ROW('xuống tinh thần', 0.75),
    ROW('cảm xúc tụt dốc', 0.82),
    ROW('down quá', 0.80),
    ROW('tệ quá', 0.78),
    ROW('thất vọng', 0.90),
    ROW('thất vọng tràn trề', 0.92),
    ROW('nản lòng', 0.85),
    ROW('kiệt quệ', 0.88),
    ROW('mông lung', 0.75),
    ROW('xa cách', 0.72),
    ROW('căng thẳng buồn', 0.70),
    ROW('bất lực', 0.90),
    ROW('mệt mỏi tinh thần', 0.88),
    ROW('heartbroken', 0.91),
    ROW('sad', 0.75),
    ROW('very sad', 0.82),
    ROW('lowkey sad', 0.78),
    ROW('feeling down', 0.76),
    ROW('feel lonely', 0.88),
    ROW('nản vãi', 0.82),
    ROW('down bad', 0.75),
    ROW('xỉu up xỉu down', 0.70),
    ROW('khó chịu trong lòng', 0.80),
    ROW('trống rỗng', 0.88),
    ROW('vô định', 0.75),
    ROW('mượn rượu giải sầu', 0.92),
    ROW('tâm trạng tệ', 0.82),
    ROW('buồn thiu', 0.80),
    ROW('chịu đựng', 0.70),
    ROW('u ám', 0.85),
    ROW('sầu não', 0.90),
    ROW('xuống mood', 0.8),
    ROW('tụt dốc cảm xúc', 0.83),
    ROW('fail mood', 0.75),
    ROW('buồn vl', 0.85),
    ROW('buồn vcl', 0.87),
    ROW('buồn quá trời', 0.78),
    ROW('buồn ơi là buồn', 0.82),
    ROW('sad quá', 0.78),
    ROW('sad vl', 0.82),
    ROW('feeling down', 0.78),
    ROW('low energy', 0.7),
    ROW('feeling empty', 0.85),
    ROW('lonely', 0.8),
    ROW('broken', 0.88),
    ROW('mentally drained', 0.87),

  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='buon'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('lo lắng',0.8),
    ROW('lo quá',0.82),
    ROW('rất lo',0.85),
    ROW('vô cùng lo lắng',0.88),
    ROW('bất an',0.82),
    ROW('bất ổn',0.78),
    ROW('nơm nớp',0.8),
    ROW('đứng ngồi không yên',0.83),
    ROW('bất chắc',0.78),
    ROW('hồi hộp lo lắng',0.81),
    ROW('hơi lo',0.68),
    ROW('lo nhẹ',0.62),
    ROW('có chút lo lắng',0.65),
    ROW('hơi bất an',0.65),
    ROW('lăn tan',0.68),
    ROW('không yên tâm',0.72),
    ROW('không chắc chắn',0.7),
    ROW('hơi sợ',0.68),
    ROW('căng thẳng nhẹ',0.7),
    ROW('lo nghĩ',0.62),
    ROW('hoảng loạn',0.93),
    ROW('hoảng sợ',0.92),
    ROW('quá tải cảm xúc',0.93),
    ROW('căng thẳng tột độ',0.92),
    ROW('rối bời',0.85),
    ROW('rối loạn',0.8),
    ROW('áp lực nặng nề',0.92),
    ROW('stress nặng',0.9),
    ROW('mất tự f',0.89),
    ROW('tim đập nhanh',0.8),
    ROW('tim đập loạn',0.82),
    ROW('thở gấp',0.82),
    ROW('khó thở',0.86),
    ROW('nghẹt thở',0.9),
    ROW('run tay',0.78),
    ROW('run rẩy',0.85),
    ROW('đổ mồ hôi',0.75),
    ROW('nhói ngực',0.82),
    ROW('chóng mặt vì lo',0.8),
    ROW('nôn nao',0.82),
    ROW('overthinking',0.85),
    ROW('suy nghĩ quá nhiều',0.83),
    ROW('lo mình không đủ tốt',0.82),
    ROW('lo về tương lai',0.8),
    ROW('ám ảnh',0.9),
    ROW('tự gây áp lực',0.82),
    ROW('đầu óc quay cuồng',0.75),
    ROW('tâm trí rối loạn',0.85),
    ROW('cảm thấy ngột ngạt',0.82),
    ROW('cảm giác nặng đầu',0.72),
    ROW('cảm giác áp lực đè nặng',0.88),
    ROW('lòng như lửa đốt',0.8),
    ROW('đứng tim',0.78),
    ROW('không dám đối mặt',0.83),
    ROW('lo vl',0.86),
    ROW('anxiety quá trời',0.82),
    ROW('run xỉu',0.8),
    ROW('căng vl',0.85),
    ROW('tâm lý bất ổn',0.85),
    ROW('nát mood vì lo',0.78),
    ROW('đau đầu luôn',0.72),
    ROW('xỉu ngang vì lo',0.8),
    ROW('lo muốn xỉu',0.82),
    ROW('anxious',0.8),
    ROW('panic',0.88),
    ROW('panic attack',0.93),
    ROW('stress',0.82),
    ROW('overwhelmed',0.88),
    ROW('nervous',0.82),
    ROW('bồn chồn',0.8),
    ROW('căng thẳng',0.8),
    ROW('nóng ruột',0.7),
    ROW('tense',0.72),
    ROW('freaked out',0.9),
    ROW('worried',0.8),
    ROW('uneasy',0.75)

  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='lo_lang'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('mệt',0.78),
    ROW('rất mệt',0.82),
    ROW('cực mệt',0.85),
    ROW('cực kỳ mệt',0.85),
    ROW('kiệt sức',0.86),
    ROW('mệt mỏi',0.8),
    ROW('uể oải',0.78),
    ROW('đuối',0.8),
    ROW('đuối sức',0.82),
    ROW('mệt rã rời',0.84),
    ROW('mệt quá trời',0.83),
    ROW('mỏi mệt',0.78),
    ROW('đau đầu',0.72),
    ROW('chóng mặt',0.75),
    ROW('buồn ngủ',0.7),
    ROW('thiếu ngủ',0.78),
    ROW('ngủ không đủ',0.75),
    ROW('không ngủ đủ',0.75),
    ROW('mệt lả',0.82),
    ROW('không còn sức',0.8),
    ROW('nhức người',0.72),
    ROW('nặng đầu',0.75),
    ROW('kiệt quệ',0.88),
    ROW('cạn kiệt năng lượng',0.9),
    ROW('cháy sạch năng lượng',0.92),
    ROW('burnout',0.92),
    ROW('suy sụp',0.9),
    ROW('hụt hơi',0.83),
    ROW('cạn sức',0.85),
    ROW('hết pin',0.88),
    ROW('muốn buông xuôi',0.9),
    ROW('muốn từ bỏ',0.9),
    ROW('không còn động lực',0.88),
    ROW('mất hứng',0.72),
    ROW('chán nản',0.82),
    ROW('chán đời',0.82),
    ROW('không muốn làm gì',0.85),
    ROW('không buồn làm gì',0.82),
    ROW('tụt mood',0.75),
    ROW('không thể tập trung',0.8),
    ROW('xuống tinh thần',0.82),
    ROW('quá tải',0.88),
    ROW('căng thẳng',0.78),
    ROW('áp lực',0.8),
    ROW('stress',0.82),
    ROW('quá sức',0.88),
    ROW('ngộp',0.85),
    ROW('ngột ngạt',0.88),
    ROW('nghẹt thở vì mệt',0.9),
    ROW('tâm trí rã rời',0.88),
    ROW('bế tắc vì mệt',0.9),
    ROW('kiệt tinh thần',0.92),
    ROW('cháy sạch năng lượng',0.92),
    ROW('hết hơi',0.72),
    ROW('xuống năng lượng',0.78),
    ROW('đuối như trái chuối',0.75),
    ROW('rã rời cả người',0.8),
    ROW('trống rỗng',0.85),
    ROW('như sắp gục',0.9),
    ROW('cảm giác muốn ngất',0.85),
    ROW('mệt muốn xỉu',0.82),
    ROW('muốn nằm xuống luôn',0.78),
    ROW('mệt đến mức không nói nổi',0.82),
    ROW('mệt vl',0.85),
    ROW('mệt vcl',0.88),
    ROW('mệt xỉu',0.8),
    ROW('heetspin vl',0.88),
    ROW('kiệt sức vl',0.88),
    ROW('hết năng lượng',0.8),
    ROW('mệt muốn khóc',0.85),
    ROW('đuối vl',0.85),
    ROW('thiếu ngủ vl',0.82),
    ROW('cạn mood',0.75),
    ROW('drain quá',0.8),
    ROW('drained',0.8),
    ROW('burnout xong luôn',0.92),
    ROW('low energy',0.72),
    ROW('overwhelmed',0.8),
    ROW('fatigue',0.8),
    ROW('mentally drained',0.92),
    ROW('emotionally tired',0.9),
    ROW('dead inside',0.92),
    ROW('thiếu năng lượng',0.8),
    ROW('tired',0.9),
    ROW('exhausted',0.8)
  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='met_moi'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('vui',0.8),
    ROW('zui',0.8),
    ROW('zui zẻ',0.82),
    ROW('vve',0.78),
    ROW('vui vẻ',0.82),
    ROW('rất vui',0.85),
    ROW('rấc vui',0.85),
    ROW('cực vui',0.87),
    ROW('vui cực',0.87),
    ROW('vui lắm',0.83),
    ROW('hào hứng',0.83),
    ROW('hồ hởi',0.8),
    ROW('sung sướng',0.84),
    ROW('hoan hỉ',0.82),
    ROW('hơi vui',0.6),
    ROW('vui chút',0.62),
    ROW('cảm thấy tốt hơn',0.7),
    ROW('đỡ hơn',0.7),
    ROW('dễ chịu',0.68),
    ROW('nhẹ nhõm',0.7),
    ROW('thoải mái',0.72),
    ROW('ấm lòng',0.75),
    ROW('biết ơn',0.74),
    ROW('ổn áp',0.72),
    ROW('hạnh phúc',0.92),
    ROW('cực kì hạnh phúc',0.95),
    ROW('hạnh phúc cực kì',0.9),
    ROW('lâng lâng',0.9),
    ROW('vỡ òa',0.93),
    ROW('hân hoan',0.87),
    ROW('mãn nguyện',0.87),
    ROW('tràn đầy năng lượng',0.88),
    ROW('thăng hoa',0.92),
    ROW('nâng mood',0.9),
    ROW('cực kỳ phấn khích',0.94),
    ROW('rất hạnh phúc',0.93),
    ROW('tươi vui',0.8),
    ROW('phấn khởi',0.82),
    ROW('happy',0.8),
    ROW('cheerful',0.8),
    ROW('như được tiếp năng lượng',0.78),
    ROW('thấy cuộc đời tươi sáng',0.82),
    ROW('nâng tinh thần',0.76),
    ROW('cảm giác thấy đầy sức sống',0.8),
    ROW('thế nhẹ người',0.75),
    ROW('mọi thứ sáng sủa',0.78),
    ROW('vui từ trong lòng',0.82),
    ROW('cười vui',0.8),
    ROW('lên mood',0.8),
    ROW('up mood',0.82),
    ROW('vui v',0.8),
    ROW('vui vcl',0.85),
    ROW('vui vãi',0.82),
    ROW('vui hơn',0.8),
    ROW('vui vl',0.87),
    ROW('vui dã man',0.85),
    ROW('vui xỉu',0.84),
    ROW('vui quá trời',0.82),
    ROW('feel good',0.8),
    ROW('best mood',0.85),
    ROW('so happy',0.85),
    ROW('excited',0.82),
    ROW('super excited',0.9),
    ROW('hyped',0.88),
    ROW('feel great',0.83),
    ROW('energetic',0.8),
    ROW('thrilled',0.88),
    ROW('overjoyed',0.91),
    ROW('cảm giác an tâm',0.72),
    ROW('vui vì có bạn',0.78),
    ROW('cảm giác gắn kết',0.75)


  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='vui'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('có động lực',1.0),
    ROW('tràn đầy động lực',1.0),
    ROW('có hứng thú',0.95),
    ROW('có mục tiêu',0.95),
    ROW('sẵn sàng cố gắng',0.95),
    ROW('quyết tâm',1.0),
    ROW('quyết chí',0.8),
    ROW('hứng khởi',0.95),
    ROW('đầy năng lương',0.95),
    ROW('muốn bắt đầu',0.8),
    ROW('nhiệt huyết',0.95),
    ROW('muốn tiến lên',0.95),
    ROW('muốn thử sức',0.95),
    ROW('thúc đẩy bản thân',0.9),
    ROW('tự thúc đẩy',0.9),
    ROW('muốn đạt được',0.9),
    ROW('sẵn sàng hành động',0.95),
    ROW('chăm chỉ',0.9),
    ROW('cố gắng',0.87),
    ROW('cố gắng hết mình',0.95),
    ROW('nỗ lực',0.85),
    ROW('nỗ lực hết mình',0.95), 
    ROW('tích cực',0.8),
    ROW('hăng hái',0.8),
    ROW('motivated',0.9),
    ROW('determined',0.8),
    ROW('theo đuổi mục tiêu',0.90),
    ROW('kiên trì',0.90),
    ROW('có mục đích',0.85),
    ROW('tập trung',0.85),
    ROW('quyết đoán',0.80),
    ROW('chủ động',0.85),
    ROW('dám thử',0.80),
    ROW('hướng về mục tiêu',0.85),
    ROW('muốn cải thiện',0.80),
    ROW('muốn làm tốt hơn',0.80),
    ROW('tiến bộ',0.80),
    ROW('phấn đấu',0.85),
    ROW('sẵn sàng thay đổi',0.80),
    ROW('muốn hoàn thành',0.85),
    ROW('định hướng rõ ràng',0.80),
    ROW('bền bỉ',0.85),
    ROW('dồn sức',0.80),
    ROW('sung sức',0.80),
    ROW('đầy khí thế',0.85),
    ROW('khí thế',0.75),
    ROW('sẵn sàng bắt tay vào việc',0.80),
    ROW('có tâm trạng làm việc',0.75),
    ROW('máu lửa',0.80),
    ROW('bừng bừng',0.75),
    ROW('tỉnh táo và sẵn sàng',0.70),
    ROW('muốn hoạt động',0.75),
    ROW('muốn làm việc',0.75),
    ROW('muốn học bài',0.75),
    ROW('có tinh thần',0.70),
    ROW('sôi nổi',0.75),
    ROW('muốn phát triển',0.80),
    ROW('muốn tự hoàn thiện',0.80),
    ROW('phát triển bản thân',0.75),
    ROW('tự tin vào khả năng',0.75),
    ROW('tự thúc đẩy mình',0.75),
    ROW('muốn thử điều mới',0.70),
    ROW('muốn tiến xa hơn',0.75),
    ROW('điều khiển bản thân',0.65),
    ROW('hướng nội lực',0.65),
    ROW('lạc quan về tương lai',0.70),
    ROW('tin mình làm được',0.75),
    ROW('đặt kế hoạch',0.70),
    ROW('sẵn sàng thử lại',0.70),
    ROW('muốn vươn lên',0.75),
    ROW('cảm thấy có hy vọng',0.65),
    ROW('cảm thấy sẵn sàng',0.75),
    ROW('có tinh thần vượt khó',0.75),
    ROW('tự tin vào khả năng',0.75),
    ROW('thực sự muốn thay đổi',0.88),
    ROW('muốn thử điều mới',0.75),
    ROW('cảm thấy sẵn sàng',0.75),
  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='co_dong_luc'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('tức giận',0.85),
    ROW('giận',0.8),
    ROW('rất giận',0.83),
    ROW('rất bực',0.82),
    ROW('rất khó chịu',0.82),
    ROW('rất cáu',0.83),
    ROW('bực mình',0.82),
    ROW('khó chịu',0.8),
    ROW('cáu',0.82),
    ROW('cáu gắt',0.85),
    ROW('phát cáu',0.85),
    ROW('điên người',0.88),
    ROW('nổi nóng',0.83),
    ROW('nóng tính',0.8),
    ROW('nổi cáu',0.85),
    ROW('gắt gỏng',0.78),
    ROW('mất kiên nhẫn',0.77),
    ROW('mất bình tĩnh',0.85),
    ROW('không chịu nổi',0.76),
    ROW('hơi bực',0.65),
    ROW('hơi khó chịu',0.63),
    ROW('khó ở',0.6),
    ROW('không vui',0.6),
    ROW('bực chút',0.62),
    ROW('phiền',0.7),
    ROW('phiền lòng',0.72),
    ROW('chán nản',0.7),
    ROW('khó chịu nhẹ',0.6),
    ROW('không hài lòng',0.72),
    ROW('thất vọng',0.7),
    ROW('giận dữ',0.9),
    ROW('cực kỳ giận',0.92),
    ROW('điên tiết',0.95),
    ROW('tức điên',0.95),
    ROW('thịnh nộ',0.95),
    ROW('nổi đóa',0.93),
    ROW('muốn đập đồ',0.95),
    ROW('muốn la lên',0.92),
    ROW('muốn chửi',0.93),
    ROW('phẫn nộ',0.95),
    ROW('điên cuồng',0.92),
    ROW('điên đầu',0.88),
    ROW('sục sôi',0.90),
    ROW('bị kích động',0.92),
    ROW('giận ai đó',0.80),
    ROW('giận bạn',0.78),
    ROW('giận bố mẹ',0.80),
    ROW('cảm thấy bị xúc phạm',0.88),
    ROW('cảm thấy bất công',0.85),
    ROW('cảm thấy bị đối xử tệ',0.82),
    ROW('bị làm tổn thương',0.75),
    ROW('tranh cãi',0.75),
    ROW('cãi nhau',0.78),
    ROW('xung đột',0.70),
    ROW('bực vì bị phớt lờ',0.80),
    ROW('bực vì điểm kém',0.78),
    ROW('bực vì làm sai',0.75),
    ROW('bực vì không được tôn trọng',0.85),
    ROW('bực vì bị áp lực',0.75),
    ROW('bực vì ai đó vô lý',0.85),
    ROW('bực vì không được nghe',0.80),
    ROW('không chịu nổi hành động của họ',0.82),
    ROW('sôi máu',0.90),
    ROW('máu dồn lên não',0.90),
    ROW('nóng máu',0.88),
    ROW('muốn nổ tung',0.92),
    ROW('muốn quát',0.85),
    ROW('đầu muốn bốc khói',0.95),
    ROW('tức muốn chết',0.92),
    ROW('muốn hét lên',0.85),
    ROW('cay',0.82),
    ROW('cay vãi',0.88),
    ROW('cay thật sự',0.90),
    ROW('tức vl',0.92),
    ROW('bực vcl',0.90),
    ROW('nóng vãi',0.85),
    ROW('điên vđ',0.92),
    ROW('tức á',0.80),
    ROW('cáu thật sự',0.88),
    ROW('khó chịu vãi',0.88),
    ROW('angry',0.80),
    ROW('pissed',0.90),
    ROW('pissed off',0.92),
    ROW('annoyed',0.78),
    ROW('irritated',0.75),
    ROW('mad',0.82),
    ROW('so mad',0.90),
    ROW('furious',0.92),
    ROW('bực bội',0.85)
    
  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='tuc_gian'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('tội lỗi',0.95),
    ROW('rất có lỗi',0.95),
    ROW('có lỗi',0.90),
    ROW('hối hận',0.90),
    ROW('ăn năn',0.92),
    ROW('hổ thẹn',0.90),
    ROW('cảm thấy tội lỗi',0.92),
    ROW('thấy có lỗi',0.90),
    ROW('cảm thấy ăn năn',0.92),
    ROW('lỗi lầm',0.88),
    ROW('sai',0.85),
    ROW('thấy mình sai',0.87),
    ROW('trách bản thân',0.88),
    ROW('tự trách mình',0.88),
    ROW('xấu hổ',0.85),
    ROW('áy náy',0.90),
    ROW('day dứt',0.92),
    ROW('hơi có lỗi',0.72),
    ROW('hơi hối hận',0.70),
    ROW('hơi áy náy',0.70),
    ROW('tiếc nuối',0.75),
    ROW('buồn vì sai',0.72),
    ROW('không yên tâm',0.70),
    ROW('không thoải mái',0.70),
    ROW('bối rối vì lỗi',0.72),
    ROW('không tự tin vì lỗi',0.70),
    ROW('cảm giác tội lỗi nhẹ',0.72),
    ROW('trách móc bản thân',0.85),
    ROW('tự dằn vặt',0.88),
    ROW('tự giày vò',0.90),
    ROW('tự trách mình vì sai',0.88),
    ROW('lỗi tại mình',0.85),
    ROW('cảm giác có lỗi với người khác',0.88),
    ROW('thấy mình sai',0.85),
    ROW('muốn sửa sai',0.80),
    ROW('nhận lỗi',0.82),
    ROW('cảm giác phải bù đắp',0.85),
    ROW('đau lòng',0.78),
    ROW('nặng lòng',0.80),
    ROW('áp lực tâm lý',0.75),
    ROW('khó chịu trong lòng',0.75),
    ROW('ngột ngạt',0.75),
    ROW('day dứt không yên',0.88),
    ROW('mất ngủ vì lỗi',0.85),
    ROW('lòng nặng trĩu',0.82),
    ROW('bứt rứt',0.80),
    ROW('căng thẳng vì lỗi',0.78),  
    ROW('cắn rứt',0.85),
    ROW('ăn năn day dứt',0.90),
    ROW('tâm trí không yên',0.80),
    ROW('trái tim nặng trĩu',0.82),
    ROW('như mang tội',0.85),
    ROW('dằn vặt trong lòng',0.88),
    ROW('muốn chuộc lỗi',0.85),
    ROW('hối hận sâu sắc',0.90),
    ROW('guilty',0.75),
    ROW('ashame',0.8),
    ROW('shameful',0.83),
    ROW('tội vl',0.88),
    ROW('tội vãi',0.88),
    ROW('hối hận vl',0.88),
    ROW('áy náy vl',0.85),
    ROW('hối vl',0.82),
    ROW('regret quá',0.80),
    ROW('day dứt vl',0.85),
    ROW('muốn sửa vl',0.80),
    ROW('lỗi vl',0.85),
    ROW('xấu hổ vl',0.80),
    ROW('sorry',0.75),
    ROW('cảm giác tội',0.78),
    ROW('nhận thức lỗi lầm',0.80),
    ROW('biết mình sai',0.80),
    ROW('muốn bù đắp',0.78),
    ROW('muốn xin lỗi',0.85),
    ROW('tự kiểm điểm',0.75),
    ROW('thấy hối hận sâu',0.82),


  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='toi_loi'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('bối rối',0.95),
    ROW('lúng túng',0.90),
    ROW('rất rối',0.9),
    ROW('rối',0.88),
    ROW('rối trí',0.90),
    ROW('rối bời',0.92),
    ROW('hoang mang',0.90),
    ROW('băn khoăn',0.88),
    ROW('bối rối không biết làm gì',0.92),
    ROW('mất phương hướng',0.9),
    ROW('mất định hướng',0.9),
    ROW('lạc lối',0.85),
    ROW('lạc lõng',0.85),
    ROW('lúng túng không biết nói gì',0.90),
    ROW('phân vân',0.88),
    ROW('hoang mang tột độ',0.92),
    ROW('rối tung',0.90),
    ROW('không biết xử lý',0.85),
    ROW('không biết phải làm sao',0.85),

    ROW('hơi bối rối',0.75),
    ROW('hơi lúng túng',0.72),
    ROW('hơi phân vân',0.70),
    ROW('hơi rối',0.72),
    ROW('có chút bối rối',0.75),
    ROW('không hiểu cho lắm',0.75),
    ROW('lúng túng chút',0.72),
    ROW('có chút phân vân',0.7),
    ROW('băn khoăn nhẹ',0.72),
    ROW('chưa chắc chắn',0.78),
    ROW('không biết chọn',0.75),
    ROW('do dự',0.78),
    ROW('lưỡng lự',0.78),
    ROW('chưa quyết định',0.75),
    ROW('không biết làm sao',0.85),
    ROW('không biết nói gì',0.85),
    ROW('bị bất ngờ',0.78),
    ROW('không hiểu chuyện gì',0.85),
    ROW('không rõ ràng',0.78),
    ROW('thiếu thông tin',0.75),
    ROW('rối vì lựa chọn',0.82),
    ROW('phân vân giữa hai lựa chọn',0.80),
    ROW('bối rối vì tình huống',0.82),
    ROW('lúng túng trong giao tiếp',0.78),
    ROW('bị sốc',0.91),

    ROW('tim đập nhanh',0.75),
    ROW('loay hoay',0.78),
    ROW('cảm giác hỗn loạn',0.80),
    ROW('mất cân bằng',0.75),
    ROW('chóng mặt',0.70),
    ROW('đầu óc quay cuồng',0.85),
    ROW('khó tập trung',0.78),
    ROW('bối rối trong lòng',0.78),
    ROW('lòng rối bời',0.80),
    ROW('hoang mang trong lòng',0.80),

    ROW('confused',0.75),
    ROW('confused af',0.77),
    ROW('lost af',0.8),
    ROW('lost',0.78),
    ROW('rối vl',0.88),
    ROW('rối vãi',0.88),
    ROW('rối v',0.85),
    ROW('chả hiểu kiểu gì',0.87),
    ROW('bối rối vl',0.85),
    ROW('lúng túng vl',0.85),
    ROW('phân vân vl',0.80),
    ROW('unsure',0.75),
    ROW('do dự vl',0.78),
    ROW('không biết làm gì cả',0.80),

    ROW('không hiểu mình muốn gì',0.78),
    ROW('chưa rõ',0.70),
    ROW('chưa quyết',0.70),
    ROW('không biết lựa chọn nào',0.80),
    ROW('rối vì thông tin',0.78),
    ROW('phân vân trong suy nghĩ',0.82),
    ROW('bối rối trong quyết định',0.82),
    ROW('không nắm rõ',0.75),
    ROW('chưa chắc',0.70),
    ROW('không rõ nên làm gì',0.78),

    ROW('đầu óc rối tung',0.90),
    ROW('tâm trí hỗn loạn',0.88),
    ROW('rối như tơ vò',0.92),
    ROW('lòng rối bời không yên',0.88),
    ROW('rối như mớ bòng bong',0.90),
    ROW('không ngừng thắc mắc',0.9),
    ROW('không thể nghĩ ra',0.88),
  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='boi_roi'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('sợ',0.9),
    ROW('rất sợ',0.92),
    ROW('sợ vô cùng',0.95),
    ROW('sợ lắm',0.92),
    ROW('sợ hãi',0.95),
    ROW('hoảng sợ',0.92),
    ROW('hoảng loạn',0.92),
    ROW('hốt hoảng',0.90),
    ROW('khiếp sợ',0.90),
    ROW('kinh hãi',0.92),
    ROW('run sợ',0.88),
    ROW('sợ đến run người',0.90),
    ROW('ám ảnh',0.85),
    ROW('lo sợ',0.88),
    ROW('hoảng hoảng',0.88),
    ROW('khủng hoảng',0.90),
    ROW('sợ phát khóc',0.90),
    ROW('sợ chết khiếp',0.92),

    ROW('tim đập nhanh',0.80),
    ROW('run tay',0.80),
    ROW('đổ mồ hôi',0.78),
    ROW('buồn nôn vì sợ',0.80),
    ROW('chân tay lạnh',0.78),
    ROW('nghẹt thở',0.85),
    ROW('căng thẳng tột độ',0.85),
    ROW('tim đập mạnh',0.82),
    ROW('khó thở',0.85),
    ROW('sợ đến nghẹn lời',0.90),

    ROW('lo lắng chuyện xấu xảy ra',0.82),
    ROW('sợ tương lai',0.80),
    ROW('sợ thất bại',0.80),
    ROW('lo sợ kết quả',0.78),
    ROW('bất an',0.82),
    ROW('lo sợ vô lý',0.75),
    ROW('sợ mất kiểm soát',0.82),
    ROW('sợ người khác đánh giá',0.80),
    ROW('căng thẳng quá mức',0.80),
    ROW('sợ sai',0.75),

    ROW('sợ bị bỏ rơi',0.85),
    ROW('sợ bị tổn thương',0.85),
    ROW('sợ đau',0.80),
    ROW('sợ kết quả xấu',0.82),
    ROW('sợ không làm được',0.78),
    ROW('sợ nói chuyện',0.80),
    ROW('sợ đám đông',0.85),
    ROW('sợ thi',0.80),
    ROW('sợ trách nhiệm',0.78),
    ROW('sợ đối mặt',0.85),

    ROW('sợ vãi',0.88),
    ROW('hãi vcl',0.82),
    ROW('sợ vl',0.88),
    ROW('sợ vcl',0.90),
    ROW('scared',0.75),
    ROW('scared af',0.90),
    ROW('freaking out',0.90),
    ROW('anxious af',0.88),
    ROW('panic',0.82),
    ROW('panic mode',0.85),
    ROW('lowkey scared',0.75),

    ROW('sợ mọi thứ',0.82),
    ROW('sợ chuyện tồi tệ xảy ra',0.88),
    ROW('nghĩ tới là sợ',0.80),
    ROW('ám ảnh nặng',0.90),
    ROW('hoảng sợ trong lòng',0.85),
    ROW('tưởng tượng điều tệ nhất',0.82),
    ROW('sợ bị chỉ trích',0.78),
    ROW('sợ bị bỏ lại',0.85),
    ROW('sợ bị thất vọng',0.78),
    ROW('sợ bị phán xét',0.80),
    ROW('lạnh sống lưng',0.90),
    ROW('nổi da gà',0.88),
    ROW('tái mặt vì sợ',0.90),
    ROW('thót tim',0.85),
    ROW('như gặp ác mộng',0.88),
    ROW('run như cầy sấy',0.90),
    ROW('sợ toát mồ hôi',0.85)

  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='so_hai'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_keywords (emotion_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword' FROM emotions, unnest(
  ARRAY[
    ROW('trung lập',1.0),
    ROW('bình thường',0.95),
    ROW('không cảm xúc',0.9),
    ROW('không rõ cảm xúc',0.9),
    ROW('không có ý kiến',0.85),
    ROW('không chắc cảm giác',0.85),
    ROW('cảm thấy ổn',0.8),
    ROW('ổn thôi',0.8),
    ROW('cũng được',0.8),
    ROW('tạm được',0.8),
    ROW('ổn mà',0.78),
    ROW('không vui không buồn',0.95),
    ROW('không có gì đặc biệt',0.8),
    ROW('mọi thứ bình thường',0.85),
    ROW('cảm giác như mọi ngày',0.8),
    ROW('khá chill',0.86),
    ROW('chill',0.83),
    ROW('không có gì khác lạ',0.8),
    ROW('không có gì nổi bật',0.8),
    ROW('không để tâm',0.85),
    ROW('không quan tâm lắm',0.75),
    ROW('thờ ơ',0.7),
    ROW('lãnh đạm',0.7),
    ROW('khá bình lặng',0.85),
    ROW('cảm xúc phẳng lặng',0.9),
    ROW('không dao động',0.85),
    ROW('bình ổn',0.9),
    ROW('khá trung tính',0.9),
    ROW('trạng thái cân bằng',0.9),
    ROW('tâm lý ổn định',0.9),
    ROW('không bị tác động',0.8),
    ROW('cảm thấy đều đều',0.8),
    ROW('mọi thứ bình thường',0.8),
    ROW('cảm thấy không đặc biệt',0.75),
    ROW('cảm thấy không rõ ràng',0.8),
    ROW('không thay đổi cảm xúc',0.9),
    ROW('neutral',0.9),
    ROW('fine',0.75),
    ROW('okay',0.75),
    ROW('ok',0.73),
    ROW('unbothered',0.8),
    ROW('stable',0.85),
    ROW('relax',0.8),
    ROW('plain',0.84),
    ROW('cảm thấy bình bình',0.8),
    ROW('cảm thấy bình thường',0.82),
    ROW('chả có gì cả',0.9),
  ]::text_weight[]
) AS t(kw text, wt numeric)
WHERE slug='trung_lap'
ON CONFLICT DO NOTHING;



-- Needs
INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('nghi_ngoi', 'Nghỉ ngơi', 'Cần được thư giãn, giảm tải, tái tạo năng lượng', 'health', 0.7, 0.8)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('an_toan', 'An toàn', 'Cần cảm giác được bảo vệ, tránh rủi ro', 'health', 0.8, 0.7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('dinh_huong', 'Định hướng', 'Cần sự rõ ràng về mục tiêu, hướng đi', 'school', 0.7, 0.6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('dong_luc', 'Động lực', 'Cần cảm hứng hoặc mục tiêu để hành động', 'school', 0.8, 0.8)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('cong_nhan', 'Được công nhận', 'Cần được đánh giá cao, công nhận nỗ lực', 'school', 0.7, 0.7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('ket_noi', 'Kết nối', 'Cần sự gần gũi, chia sẻ, hoặc hỗ trợ', 'relationship', 0.8, 0.6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('duoc_hieu', 'Được hiểu', 'Cần được lắng nghe và thấu cảm', 'relationship', 0.9, 0.7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('chap_nhan', 'Chấp nhận', 'Cần cảm giác được chấp nhận dù có khuyết điểm', 'relationship', 0.8, 0.7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('tu_ton', 'Tự tôn', 'Cần tự tin, giá trị bản thân, tự trọng', 'personal', 0.8, 0.6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('kiem_soat', 'Kiểm soát', 'Cần cảm giác chủ động, kiểm soát tình huống', 'personal', 0.7, 0.6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('y_nghia', 'Ý nghĩa', 'Cần thấy cuộc sống hoặc hành động có ý nghĩa', 'personal', 0.9, 0.6)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('binh_on', 'Bình ổn', 'Cần cân bằng, tránh quá tải cảm xúc', 'personal', 0.7, 0.8)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('hy_vong', 'Hy vọng', 'Cần niềm tin rằng mọi chuyện sẽ tốt hơn', 'personal', 0.9, 0.7)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO needs (slug, name, description, domain, priority, urgency)
VALUES
  ('khong_xac_dinh', 'Không xác định', 'Không rõ nhu cầu cụ thể', 'unknown', 0.5, 0.5)
ON CONFLICT (slug) DO NOTHING;

-- Need keywords
INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
     ROW('nghỉ ngơi',1.0),
    ROW('cần nghỉ ngơi',1.0),
    ROW('cần nghỉ một chút',0.95),
    ROW('muốn nghỉ',0.90),
    ROW('cần nghỉ xíu',0.9),
    ROW('muốn nghỉ xíu',0.85),
    ROW('muốn nghỉ giải lao',0.9),
    ROW('muốn nghỉ tạm',0.85),
    ROW('cần giải lao',0.95),
    ROW('nghỉ giải lao',0.95),
    ROW('nghỉ một lát',0.9),
    ROW('nghỉ cho khoẻ',0.95),
    ROW('thư giãn',0.85),
    ROW('cần thư giãn',0.95),
    ROW('muốn thư giãn',0.95),
    ROW('muốn xả hơi',0.95),
    ROW('xả hơi',0.9),
    ROW('thả lỏng',0.85),
    ROW('cần thả lỏng',0.95),
    ROW('muốn thả lỏng',0.95),

    ROW('kiệt sức',1.0),
    ROW('mệt mỏi quá',1.0),
    ROW('mệt quá',0.95),
    ROW('mệt rã rời',1.0),
    ROW('đuối quá',0.95),
    ROW('hết năng lượng',0.95),
    ROW('không còn sức',0.95),
    ROW('cháy pin',0.85),
    ROW('tụt pin',0.8),
    ROW('cạn pin',0.9),
    ROW('cạn năng lượng',0.95),
    ROW('hết hơi',0.85),
    ROW('căng thẳng quá',0.9),
    ROW('quá tải',0.95),
    ROW('đầu óc quá tải',1.0),
    ROW('não đơ',0.9),
    ROW('tâm trí mệt',0.95),
    ROW('kiệt tinh thần',1.0),
    ROW('nặng đầu',0.85),
    ROW('burnout',1.0),

    ROW('học nhiều quá',0.85),
    ROW('học căng quá',0.90),
    ROW('học suốt',0.85),
    ROW('làm việc quá sức',0.95),
    ROW('làm bài liên tục',0.90),
    ROW('chạy deadline',0.85),
    ROW('chạy dự án',0.80),
    ROW('bài vở dồn dập',0.90),
    ROW('lịch dày đặc',0.90),
    ROW('không có thời gian nghỉ',1.00),

    ROW('thiếu ngủ',0.95),
    ROW('mất ngủ',0.95),
    ROW('ngủ không đủ',0.90),
    ROW('ngủ muộn',0.80),
    ROW('buồn ngủ',0.85),
    ROW('ngủ gà gật',0.90),
    ROW('đầu óc mơ màng',0.90),
    ROW('thực sự cần ngủ',1.00),
    ROW('cần chợp mắt',0.95),
    ROW('muốn chợp mắt',0.95),

    ROW('không còn tâm trạng',0.85),
    ROW('cạn cảm xúc',0.90),
    ROW('không muốn làm gì',0.90),
    ROW('không buồn làm gì',0.90),
    ROW('không tập trung nổi',0.90),
    ROW('không nghĩ nổi',0.90),
    ROW('cảm thấy mệt trong người',0.95),
    ROW('chán nản vì mệt',0.95),
    ROW('kiệt quệ',1.00),
    ROW('cảm xúc xuống pin',0.85),

    ROW('tired',0.90),
    ROW('exhausted',1.00),
    ROW('drained',1.00),
    ROW('burned out',1.00),
    ROW('need rest',1.00),
    ROW('need a break',1.00),
    ROW('out of energy',0.95),
    ROW('mentally tired',1.00)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='nghi_ngoi'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('an toàn',1.00),
    ROW('cần an toàn',1.00),
    ROW('muốn an toàn',0.95),
    ROW('không an toàn',0.95),
    ROW('cảm giác không an toàn',1.00),
    ROW('cảm giác thiếu an toàn',0.95),
    ROW('thiếu an toàn',0.90),
    ROW('muốn cảm thấy an toàn',0.95),
    ROW('cần cảm giác an toàn',1.00),
    ROW('muốn được bảo vệ',1.00),
    ROW('cần được bảo vệ',1.00),
    ROW('cần được che chở',0.95),
    ROW('cảm giác dễ bị tổn thương',1.00),
    ROW('dễ bị tổn thương',0.95),
    ROW('cần sự chắc chắn',0.90),
    ROW('cần sự ổn định',0.90),
    ROW('muốn ổn định lại',0.85),
    ROW('tìm nơi an toàn',0.95),
    ROW('tìm cảm giác an toàn',1.00),
    ROW('tìm chỗ dựa',0.90),

    ROW('lo sợ',0.95),
    ROW('sợ bị tổn thương',1.00),
    ROW('sợ người khác',0.90),
    ROW('sợ chuyện xảy ra',0.90),
    ROW('sợ rủi ro',0.85),
    ROW('sợ mất kiểm soát',1.00),
    ROW('sợ không an toàn',1.00),
    ROW('cảm giác nguy hiểm',1.00),
    ROW('thấy nguy hiểm',0.95),
    ROW('môi trường không an toàn',1.00),
    ROW('bị đe doạ',1.00),
    ROW('cảm giác bị đe doạ',1.00),
    ROW('cảm thấy bị tấn công',0.90),
    ROW('bị tổn thương',0.85),
    ROW('không dám nói',0.85),
    ROW('không dám chia sẻ',0.85),
    ROW('sợ nói sai',0.85),
    ROW('sợ bị đánh giá',0.90),
    ROW('sợ bị hiểu lầm',0.85),
    ROW('sợ người khác phán xét',0.95),

    ROW('cần được trấn an',1.0),
    ROW('muốn được trấn an',1.0),
    ROW('muốn ai đó lắng nghe',0.8),
    ROW('muốn ai đó bên cạnh',0.8),
    ROW('cần cảm giác yên tâm',1.0),
    ROW('không yên tâm',0.95),
    ROW('cảm giác bất an',0.95),
    ROW('bất an',0.9),
    ROW('bất ổn trong lòng',0.85),
    ROW('cảm giác mong manh',0.9),
    ROW('dễ vỡ',0.8),
    ROW('cảm giác không chắc chắn',0.9),
    ROW('sợ tương lai',0.85),
    ROW('lo lắng về an toàn',1.0),
    ROW('cảm thấy bị đẩy ra xa',0.75),
    ROW('cảm thấy cô lập',0.85),

    ROW('không tin ai',0.85),
    ROW('không tin tưởng được',0.9),
    ROW('mất niềm tin',0.85),
    ROW('sợ bị phản bội',0.9),
    ROW('sợ bị bỏ rơi',0.9),
    ROW('sợ bị công kích online',1.0),
    ROW('bị tấn công mạng',1.0),
    ROW('sợ drama',0.75),
    ROW('sợ mâu thuẫn',0.85),
    ROW('cảm giác bị cô lập',0.85),
    ROW('cảm giác không có nơi nương tựa',0.95),

    ROW('hoảng loạn',1.0),
    ROW('hoảng sợ',1.0),
    ROW('tim đập nhanh',0.9),
    ROW('căng thẳng quá mức',0.85),
    ROW('run',0.8),
    ROW('loạn nhịp vì sợ',0.9),
    ROW('muốn trốn khỏi nơi này',0.95),
    ROW('muốn thoát khỏi tình huống này',0.95),
    ROW('muốn cảm giác yên bình',0.85),
    ROW('muốn an yên',0.85),

    ROW('feel unsafe',1.0),
    ROW('feel vulnerable',1.0),
    ROW('need safety',1.0),
    ROW('want safety',0.95),
    ROW('feel threatened',1.0),
    ROW('not safe',1.0),
    ROW('overwhelmed and scared',1.0),
    ROW('feeling exposed',0.9),
    ROW('need reassurance',1.0),
    ROW('feel anxious about safety',1.0)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='an_toan'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('định hướng',1.0),
    ROW('cần định hướng',1.0),
    ROW('muốn định hướng',0.9),
    ROW('thiếu định hướng',1.0),
    ROW('mất định hướng',1.0),
    ROW('không có định hướng',1.0),
    ROW('sai hướng',0.9),
    ROW('lạc hướng',1.0),
    ROW('mất phương hướng',1.0),
    ROW('lệch hướng',0.9),
    ROW('tìm hướng đi',1.0),
    ROW('chưa tìm được hướng đi',1.0),
    ROW('đổi hướng',0.8),
    ROW('hướng đi tương lai',1.0),
    ROW('chọn hướng đi',0.9),
    ROW('phân vân hướng đi',0.8),
    ROW('chưa biết hướng nào',0.9),
    ROW('không biết rẽ hướng nào',0.9),
    ROW('hướng dẫn',0.8),
    ROW('cần hướng dẫn',1.0),
    ROW('xin hướng dẫn',0.9),
    ROW('không biết phải làm gì',0.9),
    ROW('không hiểu chuyện gì',0.9),
    ROW('mục tiêu',0.9),
    ROW('đặt mục tiêu',1.0),
    ROW('cần mục tiêu rõ ràng',1.0),
    ROW('thiếu mục tiêu',0.9),
    ROW('không biết mục tiêu là gì',0.9),
    ROW('định mục tiêu',0.9),
    ROW('lựa chọn',0.8),
    ROW('phân vân lựa chọn',0.9),
    ROW('không quyết định được',1.0),
    ROW('cần quyết định',1.0),
    ROW('khó đưa ra quyết định',0.9),
    ROW('cần trợ giúp để quyết định',1.0),
    ROW('suy nghĩ về lựa chọn',0.8),
    ROW('tìm lựa chọn phù hợp',0.9),
    ROW('chọn hướng học',1.0),
    ROW('chọn trường',0.8),
    ROW('chọn nghề',1.0),
    ROW('chọn ngành',1.0),
    ROW('phân vân ngành học',1.0),
    ROW('kế hoạch',0.8),
    ROW('lập kế hoạch',0.9),
    ROW('lên kế hoạch',0.9),
    ROW('chưa có kế hoạch',1.0),
    ROW('không biết bắt đầu từ đâu',1.0),
    ROW('roadmap',0.7),
    ROW('vạch lộ trình',0.9),
    ROW('cần lộ trình rõ ràng',1.0),
    ROW('muốn kế hoạch rõ ràng',0.9),
    ROW('cần hướng phát triển',1.0),
    ROW('mục tiêu ngắn hạn',0.8),
    ROW('mục tiêu dài hạn',0.8),
    ROW('tự xác định hướng đi',0.9),
    ROW('muốn hiểu bản thân để chọn hướng',0.8),
    ROW('tìm điểm mạnh để định hướng',0.8),
    ROW('tìm khả năng để chọn nghề',0.8),
    ROW('cần xác định ưu tiên',0.9),
    ROW('không biết ưu tiên cái nào',0.9),
    ROW('muốn rõ ràng hơn',0.8),
    ROW('cần rõ ràng',0.8),
    ROW('đang rối trong việc lựa chọn',0.9),
    ROW('đang stuck',0.7),
    ROW('muốn tiếp tục nhưng chưa biết sao',0.7),
    ROW('need direction',0.6),
    ROW('need guidance',0.6),
    ROW('which path to take',0.6),
    ROW('confused about options',0.6),
    ROW('career direction',0.6),
    ROW('what should I choose',0.6),
    ROW('no clear plan',0.7),
    ROW('stuck with decisions',0.7)
    ROW('muốn tiến lên',0.90),
    ROW('muốn có ước mơ',0.90),
    ROW('ước mơ',0.85),
    ROW('cần ước mơ',0.85),
    ROW('có ảnh hưởng',0.85),
    ROW('muốn để lại dấu ấn',0.90),
    ROW('muốn trở thành ai đó',0.90),
    ROW('muốn thành đạt',0.90),
    ROW('có khát vọng',0.95),
    ROW('khát vọng lớn',0.95),
    ROW('muốn phát triển mạnh mẽ',0.90),
    ROW('muốn cố gắng hơn',0.90),
    ROW('muốn trưởng thành',0.90),
    ROW('phát triển kỹ năng',0.90),
    ROW('muốn học nhiều',0.85),
    ROW('muốn biết mình là ai',0.95),
    ROW('nhận biết bản thân',0.95),
    ROW('tự hiểu mình',0.90),
    ROW('khám phá bản thân',0.95),
    ROW('tìm chính mình',1.00),
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='dinh_huong'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('cần động lực', 1.0),
    ROW('không có hứng thú', 0.8)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='dong_luc'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('cần động lực',1.0),
    ROW('muốn cố gắng',0.95),
    ROW('muốn tiến bộ',0.95),
    ROW('muốn bắt đầu',0.95),
    ROW('cần cảm hứng',1.0),
    ROW('muốn được truyền cảm hứng',0.95),
    ROW('tìm nguồn động lực',0.95),
    ROW('muốn được khích lệ',0.95),
    ROW('cần ai đó thúc đẩy',0.95),
    ROW('cần ai nhắc nhở',0.95),
    ROW('cần push',0.9),
    ROW('cần boost',0.9),
    ROW('muốn quay lại quỹ đạo',0.9),
    ROW('tự tạo động lực',0.9),
    ROW('muốn tạo động lực cho bản thân',0.9),
    ROW('thiếu động lực',1.0),
    ROW('mất động lực',1.0),
    ROW('tụt động lực',0.95),
    ROW('hết động lực',1.0),
    ROW('không còn hứng thú',0.95),
    ROW('không còn năng lượng',0.95),
    ROW('chán nản',0.9),
    ROW('nản quá',0.9),
    ROW('đang stuck',0.9),
    ROW('không muốn làm gì',0.95),
    ROW('lười quá',0.9),
    ROW('trì hoãn hoài',0.9),
    ROW('không biết bắt đầu từ đâu',0.9),
    ROW('khó tập trung',0.9),
    ROW('ngồi vào bàn nhưng không làm',0.85),
    ROW('không muốn học',0.9),
    ROW('chán học',0.9),
    ROW('bài nhiều quá muốn bỏ',0.9),
    ROW('không muốn làm bài',0.9),
    ROW('không muốn ôn bài',0.85),
    ROW('học không vô',0.85),
    ROW('không muốn đi học',0.85),
    ROW('bối rối không biết làm gì trước',0.9),
    ROW('áp lực quá không muốn làm',0.9),
    ROW('ngại bắt đầu',0.85),
    ROW('chần chừ',0.85),
    ROW('sợ bắt đầu',0.85),
    ROW('chưa sẵn sàng',0.85),
    ROW('cần ai động viên',0.85),
    ROW('cần ai giúp mình bắt đầu',0.85),
    ROW('muốn tìm lý do để tiếp tục',0.85),
    ROW('cần gợi ý để làm tiếp',0.85),
    ROW('muốn ai nhắc nhở deadline',0.8),
    ROW('cần lời khích lệ',0.85),
    ROW('need motivation',0.8),
    ROW('no motivation',0.8),
    ROW('lost motivation',0.8),
    ROW('need inspiration',0.8),
    ROW('feeling unmotivated',0.8),
    ROW('stuck',0.7),
    ROW('can’t start',0.7),
    ROW('procrastinating',0.7),
    ROW('unproductive',0.7),
    ROW('need a push',0.8),
    ROW('need a boost',0.8),
    ROW('down quá',0.7),
    ROW('chán vl',0.7),
    ROW('mệt quá không làm gì',0.7),
    ROW('ngại quá',0.7),
    ROW('lười vl',0.6),
    ROW('nản vl',0.6),
    ROW('stuck quá',0.6)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='dong_luc'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('cần được công nhận',1.0),
    ROW('muốn được công nhận',1.0),
    ROW('mong được công nhận',0.95),
    ROW('cần ai đó nhìn thấy nỗ lực',0.95),
    ROW('muốn ai đó thấy thành quả',0.95),
    ROW('cần ai khen ngợi',1.0),
    ROW('muốn được khen',0.95),
    ROW('muốn được đánh giá cao',0.95),
    ROW('cần ai đó ghi nhận',0.95),
    ROW('cần lời động viên về thành tích',0.95),
    ROW('muốn ghi nhận nỗ lực',0.95),
    ROW('cần thành quả được công nhận',0.95),
    ROW('được khen', 1.0),
    ROW('được công nhận', 0.9),
    ROW('được thừa nhận', 0.9),
    ROW('cần ghi nhận', 0.9),
    ROW('được trân trọng', 0.8),
    ROW('cần sự đồng ý', 0.7),
    ROW('cảm thấy bị bỏ qua', 0.9),
    
    ROW('không được công nhận',1.0),
    ROW('bị bỏ qua',0.9),
    ROW('nỗ lực không ai thấy',0.9),
    ROW('làm mà không ai khen',0.9),
    ROW('cảm giác bị phớt lờ',0.9),
    ROW('ai cũng quên mình',0.85),
    ROW('bị đánh giá thấp',0.9),
    ROW('không được đánh giá đúng',0.9),
    ROW('cảm giác vô hình',0.85),
    ROW('thành quả bị bỏ qua',0.9),
    ROW('làm xong mà không ai chú ý',0.85),

    ROW('muốn được mọi người chú ý',0.9),
    ROW('muốn được mọi người công nhận',0.9),
    ROW('cần được bạn bè khen',0.85),
    ROW('cần được thầy cô công nhận',0.85),
    ROW('muốn được đồng nghiệp ghi nhận',0.85),
    ROW('muốn được ghi nhận trên mạng',0.8),
    ROW('cần like',0.8),
    ROW('cần comment',0.8),
    ROW('cần share',0.8),

    ROW('muốn được thấy giá trị của mình',0.85),
    ROW('cần ai đó thừa nhận mình',0.85),
    ROW('muốn được công nhận năng lực',0.85),
    ROW('muốn được đánh giá đúng khả năng',0.85),
    ROW('cần sự xác nhận từ người khác',0.85),
    ROW('cần lời khích lệ để thấy giá trị',0.85),

    ROW('need recognition',0.8),
    ROW('want appreciation',0.8),
    ROW('feeling ignored',0.8),
    ROW('nobody notices me',0.8),
    ROW('want credit',0.8),
    ROW('need acknowledgment',0.8),
    ROW('unrecognized',0.75),
    ROW('feel overlooked',0.75),
    ROW('need props',0.7),
    ROW('want someone to notice',0.75),
    ROW('need shoutout',0.7),
    ROW('need thumbs up',0.7),
    ROW('feel invisible',0.75),
    ROW('need likes',0.7),
    ROW('feel forgotten',0.7),
    ROW('need respect',0.75),
    ROW('feeling underappreciated',0.8),
    ROW('need validation',0.75),
    ROW('need some validation',0.7),
    ROW('need a pat on the back',0.7),

    ROW('ai để ý gì đâu',0.7),
    ROW('chẳng ai để ý',0.7),
    ROW('chán vì làm mà không ai khen',0.7),
    ROW('làm nhiều mà chẳng ai thèm nói gì',0.7),
    ROW('feel unnoticed',0.7),
    ROW('no one cares',0.6),
    ROW('nobody cares',0.6),
    ROW('cần ai đó ghi nhận chút thôi',0.65)
    ROW('không ai quan tâm',0.7),
    ROW('chả ai để ý',0.75),
    ROW('chả ai quan tâm',0.75),
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='cong_nhan'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('cần kết nối',1.0),
    ROW('muốn kết nối',1.0),
    ROW('cần nói chuyện với ai đó',0.95),
    ROW('cần ai đó lắng nghe',0.95),
    ROW('cần người tâm sự',1.0),
    ROW('muốn được chia sẻ',0.95),
    ROW('cần có người hiểu mình',0.95),
    ROW('muốn có ai đó ở bên',1.0),
    ROW('cần người đồng hành',0.95),
    ROW('cần một cuộc trò chuyện thật sự',0.95),
    ROW('muốn gần gũi với ai đó',0.95),
    ROW('muốn cảm giác thuộc về đâu đó',0.95),

    ROW('cảm thấy cô đơn',1.0),
    ROW('thấy lạc lõng',0.9),
    ROW('không có ai để nói chuyện',0.9),
    ROW('chẳng ai hiểu mình',0.9),
    ROW('cảm giác bị tách biệt',0.9),
    ROW('thấy lạc lõng giữa mọi người',0.9),
    ROW('bị tách rời khỏi mọi người',0.85),
    ROW('cảm thấy xa cách',0.9),
    ROW('mất kết nối với bạn bè',0.9),
    ROW('chẳng ai quan tâm',0.9),
    ROW('không ai để dựa vào',0.9),
    ROW('thấy mình không thuộc về nơi nào',0.9),
    ROW('cảm giác trống rỗng vì không có ai',0.9),
    ROW('bị bỏ rơi',0.9),
    ROW('bị phớt lờ',0.9),
    ROW('bị cô lập',0.9),

    ROW('muốn đi chơi cùng ai đó',0.85),
    ROW('muốn tâm sự với ai đó',0.9),
    ROW('muốn giao lưu',0.85),
    ROW('muốn nói chuyện nhiều hơn',0.85),
    ROW('muốn kết bạn',0.85),
    ROW('muốn tìm sự kết nối mới',0.85),
    ROW('muốn ở gần bạn bè',0.85),
    ROW('cần cảm giác thân thuộc',0.9),
    ROW('muốn được chấp nhận trong nhóm',0.85),
    ROW('muốn được hòa nhập',0.85),

    ROW('cần sự quan tâm',0.85),
    ROW('muốn được ôm',0.8),
    ROW('muốn có ai đó cạnh bên',0.85),
    ROW('cảm thấy cần tình cảm',0.8),
    ROW('muốn cảm giác gần gũi',0.85),
    ROW('muốn sự ấm áp',0.85),
    ROW('muốn ai đó lắng nghe thấu hiểu',0.85),
    ROW('muốn người tin tưởng mình',0.85),
    ROW('muốn ai đó stay with me',0.8),

    ROW('em không có ai để dựa',0.8),
    ROW('bạn bè xa lánh',0.8),
    ROW('không ai rảnh để nghe mình nói',0.75),
    ROW('khó kết nối với người khác',0.75),
    ROW('chẳng thân với ai',0.7),
    ROW('thấy mình bị bỏ lại',0.75),
    ROW('không hòa nhập được',0.75),
    ROW('cảm giác tránh xa mọi người',0.7),
    ROW('cảm giác disconnected',0.7),

    ROW('feel lonely',0.8),
    ROW('feeling alone',0.8),
    ROW('need someone to talk to',0.8),
    ROW('need connection',0.8),
    ROW('want to talk to someone',0.8),
    ROW('want company',0.75),
    ROW('want someone to listen',0.75),
    ROW('feel isolated',0.75),
    ROW('feel disconnected',0.75),
    ROW('need social support',0.75),
    ROW('need a friend',0.75),
    ROW('wanna talk',0.7),
    ROW('need someone here with me',0.7),
    ROW('want to feel belonged',0.75),
    ROW('no one to talk to',0.7),
    ROW('feel left out',0.7),
    ROW('no connections',0.7),
    ROW('socially drained',0.65),
    ROW('socially isolated',0.65),
    ROW('friendless',0.75)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='ket_noi'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
  ROW('bị hiểu lầm',1.0),
  ROW('bị hiểu sai',1.0),
  ROW('bị đánh giá nhầm',0.95),
  ROW('bị nhìn nhận sai',0.95),
  ROW('người ta nghĩ sai về tôi',0.9),
  ROW('bị gán cho điều không phải của mình',0.9),
  ROW('nói một đường người ta nghĩ một nẻo',0.9),
  ROW('bị xuyên tạc lời nói',0.9),
  ROW('bị nhìn sai bản chất',0.95),
  ROW('không ai hiểu lý do của tôi',0.9),
  ROW('tôi không như họ nghĩ',0.9),
  ROW('họ không hiểu tôi',0.9),
  ROW('cần được thấu cảm',1.0),
  ROW('cần sự thông cảm',1.0),
  ROW('muốn được hiểu mà không bị phán xét',1.0),
  ROW('muốn được nhìn từ góc nhìn của tôi',0.95),
  ROW('cần ai đó hiểu cảm xúc của tôi',0.95),
  ROW('cần sự đồng điệu cảm xúc',0.9),
  ROW('ước gì có ai hiểu tôi',0.9),
  ROW('muốn được lắng nghe chân thành',0.95),
  ROW('muốn được nghe mà không bị ngắt lời',0.95),
  ROW('cảm xúc của tôi bị bỏ qua',1.0),
  ROW('bị phớt lờ',1.0),
  ROW('lời tôi nói bị xem nhẹ',0.95),
  ROW('ý kiến của tôi không ai nghe',0.95),
  ROW('cảm thấy bị coi thường',0.9),
  ROW('bị làm ngơ',0.9),
  ROW('bị xem như không tồn tại',1.0),
  ROW('khó diễn đạt',0.8),
  ROW('khó nói hết lòng mình',0.8),
  ROW('nói không trọn ý',0.75),
  ROW('không biết truyền đạt',0.7),
  ROW('diễn đạt khó quá',0.7),
  ROW('không ai bắt được ý',0.75),
  ROW('nói sai một chút là bị hiểu lầm',0.85),
  ROW('mỗi lần nói đều gây hiểu lầm',0.85),
  ROW('muốn được lắng nghe',1.0),
  ROW('cần ai đó ngồi nghe tôi',0.95),
  ROW('muốn có người chịu nghe',0.9),
  ROW('muốn tâm sự',0.8),
  ROW('cần cuộc nói chuyện chân thành',0.9),
  ROW('cần người nghe không phán xét',1.0),
  ROW('muốn được nghe đến hết câu',0.95),
  ROW('không ai hiểu cảm xúc của tôi',1.0),
  ROW('cảm giác một mình trong cảm xúc',0.95),
  ROW('nỗi lòng không ai thấu',1.0),
  ROW('không ai cùng tần số với tôi',0.85),
  ROW('cảm xúc bị kẹt trong lòng',0.8),
  ROW('chỉ có mình tôi hiểu được cảm xúc này',0.9),
  ROW('chán vì phải giải thích hoài',0.9),
  ROW('mệt vì bị hiểu sai',1.0),
  ROW('mệt vì phải lặp lại',0.85),
  ROW('bực vì không ai hiểu ý',0.9),
  ROW('nản vì cố giải thích',0.85),
  ROW('bất lực khi người ta không hiểu',1.0),
  ROW('muốn được nhìn thấy con người thật',1.0),
  ROW('muốn được nhìn nhận đúng',1.0),
  ROW('muốn người khác hiểu tôi hơn',0.95),
  ROW('không ai biết tôi thật sự',0.9),
  ROW('muốn được hiểu nỗ lực của tôi',0.9),
  ROW('muốn được hiểu mà không bị định kiến',1.0),
  ROW('nói gì cũng không ai hiểu',1.0),
  ROW('như nói hai ngôn ngữ khác nhau',0.8),
  ROW('không chung tần số nói chuyện',0.75),
  ROW('tôi nói người ta hiểu theo ý họ',0.85),
  ROW('không truyền tải được cảm xúc',0.9),
  ROW('nói chuyện không đâu vào đâu',0.8)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='duoc_hieu'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('muốn được chấp nhận',1.0),
    ROW('muốn được công nhận',0.95),
    ROW('muốn được coi trọng',0.9),
    ROW('muốn được xem là một phần',0.95),
    ROW('muốn được chào đón',0.9),
    ROW('muốn được tiếp nhận',0.85),
    ROW('muốn được thừa nhận',0.95),
    ROW('muốn được đối xử như mọi người',0.9),
    ROW('muốn được chấp nhận như đúng bản thân mình',1.0),
    ROW('muốn được yêu thương như chính mình',1.0),
    ROW('muốn được công nhận nỗ lực',0.95),
    ROW('sợ bị từ chối',1.0),
    ROW('sợ bị loại bỏ',1.0),
    ROW('sợ bị xa lánh',0.95),
    ROW('sợ không được chấp nhận',0.95),
    ROW('lo bị đánh giá',0.95),
    ROW('sợ bị tẩy chay',1.0),
    ROW('sợ mọi người không thích mình',0.9),
    ROW('sợ không hợp nhóm',0.85),
    ROW('muốn được ghi nhận',0.95),
    ROW('muốn được khen ngợi',0.85),
    ROW('muốn được xác nhận',0.9),
    ROW('muốn được công nhận cảm xúc',0.95),
    ROW('cần được xác nhận rằng mình đủ tốt',0.95),
    ROW('cần ai đó đứng về phía tôi',0.95),
    ROW('cảm thấy không được chấp nhận',1.0),
    ROW('cảm thấy bị loại ra',1.0),
    ROW('cảm thấy không thuộc về nơi này',0.95),
    ROW('cảm thấy bị gạt ra ngoài',0.95),
    ROW('cảm thấy không được coi trọng',0.9),
    ROW('cảm thấy bị xa lánh',0.95),
    ROW('cảm thấy bị bỏ rơi',1.0),
    ROW('cảm thấy bị xem thường',0.9),
    ROW('ước được chấp nhận như chính mình',1.0),
    ROW('ước được yêu mà không bị so sánh',0.9),
    ROW('chỉ muốn ai đó chấp nhận mình',0.95),
    ROW('mong được công nhận giá trị',0.95),
    ROW('mong không bị đánh giá',0.9),
    ROW('muốn hòa nhập',0.85),
    ROW('muốn thuộc về một nhóm',0.9),
    ROW('muốn trở thành một phần',0.9),
    ROW('muốn được mời tham gia',0.85),
    ROW('muốn được xem như thành viên thật sự',0.9),
    ROW('không ai muốn chơi với tôi',1.0),
    ROW('bị loại khỏi nhóm',1.0),
    ROW('bị cho ra rìa',0.95),
    ROW('bị xa lánh',1.0),
    ROW('bị nói xấu sau lưng',0.9),
    ROW('cảm giác bị loại trừ',0.95),
    ROW('không ai tôn trọng tôi',0.9),
    ROW('tôi không đủ tốt',1.0),
    ROW('tôi không xứng đáng',1.0),
    ROW('tôi không đáng được yêu',0.95),
    ROW('tôi không giá trị',0.95),
    ROW('tôi thấy mình vô dụng',1.0),
    ROW('tôi thấy mình không quan trọng',0.95),
    ROW('muốn được chấp nhận cảm xúc',0.95),
    ROW('muốn được lắng nghe mà không bị chê cười',0.95),
    ROW('muốn ai đó nói tớ hiểu cậu',0.9),
    ROW('muốn được tha thứ',0.85)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='chap_nhan'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('tự tin', 1.0),
    ROW('tự trọng', 0.9),
    ROW('muốn được tôn trọng', 0.9),
    ROW('giá trị bản thân', 0.9),
    ROW('cảm thấy bị coi thường', 0.9),
    ROW('khẳng định bản thân', 0.8),
    ROW('muốn tự hào về bản thân', 0.8),
    ROW('không muốn bị coi nhẹ', 0.9)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='tu_ton'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('cần kiểm soát', 1.0),
    ROW('chủ động', 0.9),
    ROW('muốn tự quyết định', 0.9),
    ROW('cần quyền lựa chọn', 0.8),
    ROW('muốn tự lập', 0.8),
    ROW('bị kiểm soát quá mức', 0.9),
    ROW('cần kiểm soát tình huống', 0.9),
    ROW('tự quản lý', 0.8),

    ROW('tự tin', 1.0),
    ROW('tự trọng', 1.0),
    ROW('tự tôn', 1.0),
    ROW('lòng tự trọng bị tổn thương', 1.0),
    ROW('muốn được tôn trọng', 0.95),
    ROW('muốn được ghi nhận', 0.9),
    ROW('cần sự công nhận', 0.9),
    ROW('giá trị bản thân', 0.95),
    ROW('cảm thấy bị coi thường', 0.95),
  ROW('cảm thấy bị hạ thấp', 0.9),
  ROW('khẳng định bản thân', 0.9),
  ROW('không muốn bị coi nhẹ', 0.9),
  ROW('cảm giác không có giá trị', 0.95),
  ROW('thấy bản thân kém cỏi', 0.9),
  ROW('cảm giác không đủ tốt', 0.8),
  ROW('sự tự hào cá nhân', 0.85),
  ROW('mong được đánh giá cao', 0.9),
  ROW('mong có sự tôn trọng', 0.9),
  ROW('tìm kiếm sự công nhận', 0.85),
  ROW('cần được lắng nghe', 0.8),
  ROW('cần được xem trọng', 0.9),
  ROW('cần sự đánh giá đúng', 0.85),
  ROW('tìm kiếm sự khẳng định', 0.85),
  ROW('sợ bị đánh giá thấp', 0.85),
  ROW('sợ bị xem thường', 0.9),
  ROW('ghét cảm giác bị coi nhẹ', 0.9),
  ROW('muốn chứng minh bản thân', 0.8),
  ROW('mong muốn được công nhận', 0.9),
  ROW('cảm giác bị bỏ qua', 0.75),
  ROW('cảm giác bị xem nhẹ', 0.8),
  ROW('mong được tôn vinh', 0.7),
  ROW('muốn được tán dương', 0.75),
  ROW('muốn được đánh giá đúng', 0.8),
  ROW('muốn được đối xử công bằng', 0.75),
  ROW('muốn được nhìn nhận nghiêm túc', 0.85),
  ROW('tự đánh giá bản thân thấp', 0.8),
  ROW('mất tự tin', 0.8),
  ROW('cảm thấy bị phủ nhận', 0.9),
  ROW('không được coi trọng', 0.9),
  ROW('cảm giác không được ghi nhận', 0.85),
  ROW('công nhận bản thân', 0.75),
  ROW('muốn nâng giá trị bản thân', 0.8),
  ROW('khát khao tự khẳng định', 0.85),
  ROW('bị xem thường', 0.9),
  ROW('tổn thương tự trọng', 1.0),
  ROW('tự tin vào khả năng', 0.7),
  ROW('tin vào giá trị bản thân', 0.8),
  ROW('xây dựng tự trọng', 0.75),
  ROW('khủng hoảng tự tôn', 1.0),

  ROW('self-esteem', 1.0),
  ROW('self-worth', 1.0),
  ROW('self-respect', 1.0),
  ROW('hurt pride', 1.0),
  ROW('feeling undervalued', 0.95),
  ROW('feeling worthless', 0.95),
  ROW('feeling unappreciated', 0.9),
  ROW('seeking validation', 0.9),
  ROW('need for recognition', 0.9),
  ROW('feeling disrespected', 0.95),
  ROW('feeling belittled', 0.9),
  ROW('feeling inferior', 0.9),
  ROW('need to prove worth', 0.85),
  ROW('proving oneself', 0.85),
  ROW('desire for acknowledgement', 0.9),
  ROW('need to be taken seriously', 0.9),
  ROW('feeling dismissed', 0.9),
  ROW('feeling unimportant', 0.8),
  ROW('doubt in self-worth', 0.9),
  ROW('low self-esteem', 0.9),
  ROW('questioning self-value', 0.9),
  ROW('searching for validation', 0.9),
  ROW('desire for respect', 0.9),
  ROW('lack of confidence', 0.75),
  ROW('wanting recognition', 0.85),
  ROW('craving respect', 0.85),
  ROW('wanting to be valued', 0.9),
  ROW('not feeling valued', 0.9),
  ROW('not being taken seriously', 0.9),
  ROW('being looked down on', 0.95),
  ROW('feeling inferior to others', 0.85),
  ROW('feeling overshadowed', 0.8),
  ROW('feeling insignificant', 0.8),
  ROW('seeking appreciation', 0.85),
  ROW('need for affirmation', 0.85),
  ROW('being underestimated', 0.9),
  ROW('hurt self-image', 0.9),
  ROW('protecting self-worth', 0.75),
  ROW('strengthening self-esteem', 0.75),
  ROW('personal value', 0.7),
  ROW('personal dignity', 0.8),
  ROW('feeling disregarded', 0.9),
  ROW('feeling minimized', 0.85),
  ROW('desire to feel proud', 0.8),
  ROW('need to be respected', 0.9),
  ROW('wanting fair treatment', 0.7),
  ROW('wanting appreciation', 0.8),
  ROW('craving recognition', 0.85),
  ROW('challenged pride', 0.95),
  ROW('threatened self-esteem', 1.0),
  ROW('boosting self-worth', 0.75)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='kiem_soat'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('ý nghĩa', 1.0),
    ROW('cảm thấy vô nghĩa', 0.9),
    ROW('không thấy mục đích', 0.8),
    ROW('cần lý do sống', 0.9),
    ROW('cần mục tiêu', 0.9),
    ROW('muốn đóng góp', 0.7),
    ROW('không biết tại sao', 0.9),
    ROW('muốn hiểu ý nghĩa', 0.9),
    ROW('cảm thấy trống rỗng', 0.8),

    ROW('ý nghĩa cuộc sống', 0.95),
    ROW('cảm thấy vô nghĩa', 0.90),
    ROW('không thấy giá trị bản thân', 0.90),
    ROW('cảm thấy trống rỗng bên trong', 0.85),
    ROW('tự hỏi điều gì khiến mình quan trọng', 0.85),
    ROW('không biết điều gì làm mình có ích', 0.85),
    ROW('muốn cảm thấy có giá trị', 0.90),
    ROW('muốn cảm thấy mình quan trọng', 0.85),
    ROW('muốn có lý do để cố gắng', 0.85),
    ROW('muốn sống có ý nghĩa hơn', 0.90),
    ROW('cảm thấy đời mình nhạt nhẽo', 0.80),
    ROW('không thấy điều gì thúc đẩy bản thân', 0.80),
    ROW('cảm thấy mọi thứ mờ nhạt', 0.80),
    ROW('không thấy mình đóng góp gì', 0.85),
    ROW('muốn làm điều có ích', 0.85),
    ROW('cần tìm điều khiến mình sống tích cực', 0.85),
    ROW('cảm thấy mất kết nối với chính mình', 0.85),
    ROW('không thấy điều gì khiến mình hạnh phúc', 0.80),
    ROW('cảm thấy như đang tồn tại chứ không sống', 0.90),
    ROW('tự hỏi điều gì tạo giá trị cho bản thân', 0.85),
    ROW('cảm thấy cuộc sống vô vị', 0.80),
    ROW('muốn hiểu mình có giá trị gì', 0.85),
    ROW('cảm giác cuộc sống trôi qua vô nghĩa', 0.90),
    ROW('không thấy điều gì đáng để quan tâm', 0.85),
    ROW('muốn thấy mình có tác động tích cực', 0.85),
    ROW('cảm thấy cuộc sống thiếu linh hồn', 0.80),
    ROW('không thấy điều gì làm mình hứng thú', 0.80),
    ROW('muốn tìm điều làm bản thân thấy sống hơn', 0.85),
    ROW('cảm thấy như một phần bên trong bị rỗng', 0.85),
    ROW('không biết điều gì mang lại giá trị thật', 0.85),
    ROW('cảm thấy cuộc sống lặp lại vô nghĩa', 0.85),
    ROW('cần điều gì đó sâu sắc hơn', 0.80),
    ROW('cần cảm giác mình có tầm quan trọng', 0.85),
    ROW('muốn hiểu bản thân mang lại điều gì', 0.85),
    ROW('cảm thấy thiếu sức sống', 0.80),
    ROW('không biết bản thân có đóng góp gì không', 0.85),
    ROW('muốn cảm thấy mình xứng đáng', 0.85),
    ROW('cảm thấy mọi thứ nhàm chán', 0.75),
    ROW('không biết điều gì khiến mình có giá trị', 0.85),
    ROW('tự hỏi mình đang sống cho điều gì', 0.90),
    ROW('không thấy mục tiêu cảm xúc nào', 0.80),
    ROW('muốn có điều khiến mình thấy sống ý nghĩa', 0.90),
    ROW('không tìm được cảm giác ý nghĩa', 0.85),
    ROW('cảm thấy bản thân mờ nhạt', 0.80),
    ROW('không biết bản thân quan trọng với ai', 0.80),
    ROW('cần cảm cảm giác có ý nghĩa', 0.90),
    ROW('muốn tìm sự kết nối sâu sắc với cuộc sống', 0.85),
    ROW('thấy bản thân không nổi bật', 0.80),
    ROW('cảm thấy như đang bị trôi dạt trong cuộc sống', 0.85),\

    ROW('searching for meaning', 0.95),
    ROW('feeling empty inside', 0.90),
    ROW('feeling meaningless', 0.90),
    ROW('want to feel valuable', 0.90),
    ROW('don’t feel important', 0.85),
    ROW('can’t find meaning in things', 0.85),
    ROW('feel like nothing matters', 0.90),
    ROW('struggling to feel purpose', 0.85),
    ROW('feeling emotionally empty', 0.85),
    ROW('want to feel like I matter', 0.85),
    ROW('feeling unfulfilled', 0.85),
    ROW('nothing feels meaningful', 0.85),
    ROW('don’t feel connected to myself', 0.85),
    ROW('feeling hollow', 0.85),
    ROW('struggling to feel alive', 0.85),
    ROW('want to feel useful', 0.85),
    ROW('hard to care about things', 0.80),
    ROW('feel like I’m drifting emotionally', 0.85),
    ROW('don’t feel excited about life', 0.80),
    ROW('can’t find emotional purpose', 0.80),
    ROW('want something deeper', 0.80),
    ROW('don’t feel like I contribute anything', 0.85),
    ROW('feeling numb to everything', 0.85),
    ROW('nothing feels important', 0.85),
    ROW('feel like I’m just existing', 0.90),
    ROW('don’t know what gives me meaning', 0.85),
    ROW('can’t feel any joy or spark', 0.80),
    ROW('feeling lost emotionally', 0.85),
    ROW('feel like my life has no depth', 0.85),
    ROW('don’t know what makes me feel alive', 0.85),
    ROW('feeling unmotivated emotionally', 0.80),
    ROW('want to feel like I matter to something', 0.85),
    ROW('everything feels dull', 0.75),
    ROW('feel like I’m disappearing', 0.80),
    ROW('hard to connect with anything', 0.80),
    ROW('want to understand my emotional value', 0.85),
    ROW('feel disconnected from life', 0.85),
    ROW('nothing feels real emotionally', 0.85),
    ROW('feeling like a ghost in my own life', 0.85),
    ROW('struggling to find emotional meaning', 0.85),
    ROW('feeling emotionally directionless', 0.85),
    ROW('feel like I’m fading', 0.80),
    ROW('don’t feel like I belong anywhere emotionally', 0.80),
    ROW('want to feel emotionally alive', 0.85),
    ROW('hard to feel my own value', 0.85),
    ROW('feel like everything is empty', 0.85),
    ROW('searching for emotional meaning', 0.90),
    ROW('don’t know what makes my life meaningful', 0.85),
    ROW('feel like my presence doesn’t matter', 0.85)

  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='y_nghia'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('bình ổn', 1.0),
    ROW('tâm trạng bình ổn', 1.0),
    ROW('giữ tâm vững', 0.95),
    ROW('cảm xúc ổn định', 0.95),
    ROW('tinh thần ổn định', 0.9),
    ROW('cần sự bình tĩnh', 0.9),
    ROW('tâm lý ổn định', 0.9),
    ROW('tinh thần yên ổn', 0.9),
    ROW('giữ sự bình yên', 0.9),
    ROW('muốn lòng yên lại', 0.9),
    ROW('đầu óc nhẹ nhàng', 0.85),
    ROW('tâm không xáo động', 0.9),
    ROW('muốn mọi thứ yên', 0.85),
    ROW('ổn định cảm xúc', 0.9),
    ROW('bớt căng thẳng lại', 0.85),
    ROW('bình tĩnh hơn chút', 0.85),
    ROW('không muốn rối nữa', 0.85),
    ROW('tránh bị quá tải', 0.85),
    ROW('muốn giảm áp lực', 0.85),
    ROW('cần sự nhẹ nhàng', 0.8),
    ROW('tâm lý thoải mái', 0.85),
    ROW('tinh thần thư thái', 0.85),
    ROW('mong được yên ổn', 0.9),
    ROW('đầu óc bình thản', 0.9),
    ROW('tìm sự cân bằng', 0.9),
    ROW('cuộc sống nhẹ nhàng', 0.8),
    ROW('không muốn stress', 0.8),
    ROW('tránh xung đột', 0.75),
    ROW('muốn sống chậm lại', 0.8),
    ROW('muốn tâm yên', 0.9),
    ROW('sống cho nhẹ đầu', 0.8),
    ROW('muốn đỡ rối hơn', 0.85),
    ROW('muốn chill lại chút', 0.75),
    ROW('vibe yên ổn hơn', 0.75),
    ROW('bớt drama lại', 0.75),
    ROW('cần reset tinh thần', 0.8),
    ROW('bị overwhelm quá', 0.7),
    ROW('đầu óc lộn xộn', 0.8),
    ROW('cần không gian thở', 0.8),
    ROW('quay về trạng thái ổn', 0.8),
    ROW('ngắt kết nối một chút', 0.7),
    ROW('đầu óc bớt nặng', 0.8),
    ROW('cần ổn ổn lại', 0.8),
    ROW('mọi thứ calm lại', 0.8),
    ROW('tinh thần không tụt mood', 0.75),
    ROW('lòng bình thì sống yên', 0.9),
    ROW('thả lỏng mà sống', 0.85),
    ROW('nhẹ đầu nhẹ lòng', 0.85),
    ROW('tĩnh thì an', 0.9),
    ROW('giữ lòng yên', 0.9),
    ROW('sống chậm cho an', 0.85),
    ROW('an thì mới ổn', 0.9),
    ROW('tâm yên thì đời yên', 0.95),
    ROW('thở sâu để bình an', 0.85),
    ROW('bình tĩnh là sức mạnh', 0.85),
    ROW('cứ từ từ rồi ổn', 0.8),
    ROW('lòng vững thì không lo', 0.85),
    ROW('chậm lại để ổn định', 0.8),
    ROW('cần yên tĩnh để ổn lại', 0.9),

    ROW('emotional stability', 1.0),
    ROW('feeling grounded', 0.95),
    ROW('inner calm', 0.95),
    ROW('stable mindset', 0.9),
    ROW('mental balance', 0.9),
    ROW('calm and steady', 0.9),
    ROW('need to calm down', 0.9),
    ROW('mind feels steady', 0.9),
    ROW('reset my mind', 0.85),
    ROW('need to slow down', 0.85),
    ROW('want things calmer', 0.85),
    ROW('keep myself grounded', 0.9),
    ROW('feeling overwhelmed', 0.8),
    ROW('too much going on', 0.8),
    ROW('mind feels messy', 0.85),
    ROW('need some quiet', 0.85),
    ROW('need a breather', 0.85),
    ROW('brain needs rest', 0.85),
    ROW('mental reset', 0.85),
    ROW('lower the stress', 0.8),
    ROW('stay calm and steady', 0.9),
    ROW('want peace of mind', 0.95),
    ROW('seeking balance', 0.9),
    ROW('want emotional peace', 0.95),
    ROW('mind feeling heavy', 0.85),
    ROW('need to decompress', 0.85),
    ROW('trying to stay calm', 0.85),
    ROW('feel mentally drained', 0.8),
    ROW('keep things peaceful', 0.85),
    ROW('head feels too full', 0.8),
    ROW('just want calm', 0.9),
    ROW('things feel chaotic', 0.85),
    ROW('need to breathe', 0.85),
    ROW('want everything steady', 0.9),
    ROW('trying to stay stable', 0.9),
    ROW('need mental quiet', 0.9),
    ROW('take it slow', 0.8),
    ROW('calm my thoughts', 0.9),
    ROW('clear my mind', 0.85),
    ROW('find some peace', 0.9),
    ROW('stay emotionally steady', 0.9),
    ROW('feel inner peace', 0.95),
    ROW('trying to stay centered', 0.9),
    ROW('want to feel balanced', 0.95),
    ROW('brain feels overloaded', 0.8),
    ROW('reduce the noise', 0.8),
    ROW('calm energy', 0.85),
    ROW('stay grounded', 0.9),
    ROW('mind needs calm', 0.9),
    ROW('want some stability', 1.0),
    ROW('mental calmness', 0.9)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='binh_on'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('muốn có hy vọng', 1.0),
    ROW('tin tưởng vào tương lai', 0.9),
    ROW('muốn lạc quan', 0.9),
    ROW('cần động lực', 0.7),
    ROW('mong mọi việc tốt đẹp', 0.9),
    ROW('cần niềm hy vọng', 0.9),
    ROW('cảm thấy mất hi vọng', 0.8),
    ROW('tuyệt vọng', 0.8),
    ROW('cần niềm tin', 0.8),

    ROW('cảm thấy bế tắc', 1.0),
    ROW('không còn thấy lối ra', 1.0),
    ROW('mọi thứ đều mù mịt', 0.95),
    ROW('không biết rồi có khá lên không', 0.95),
    ROW('cảm thấy mất niềm tin', 0.95),
    ROW('tương lai trông tối quá', 0.9),
    ROW('lo sợ mọi thứ tệ hơn', 0.9),
    ROW('không biết vượt qua kiểu gì', 0.9),
    ROW('cảm giác bất lực', 0.95),
    ROW('nặng nề trong lòng', 0.85),
    ROW('cảm thấy không ổn chút nào', 0.85),
    ROW('mọi thứ đang sụp xuống', 0.9),
    ROW('cảm thấy bị mắc kẹt lâu rồi', 0.9),
    ROW('không dám hi vọng nữa', 0.95),
    ROW('cảm giác quá sức chịu', 0.9),
    ROW('không thấy điểm sáng nào', 0.95),
    ROW('khó mà tin mọi thứ sẽ ổn', 0.95),
    ROW('cảm giác hụt hẫng', 0.8),
    ROW('thấy cuộc sống nặng quá', 0.85),
    ROW('không biết phải làm sao để nhẹ hơn', 0.85),
    ROW('mệt vì phải cố gắng mãi', 0.9),
    ROW('mọi thứ cứ tệ dần', 0.9),
    ROW('sợ mình không vượt qua nổi', 0.95),
    ROW('nhìn đâu cũng thấy khó', 0.85),
    ROW('khó tin vào điều tốt', 0.9),
    ROW('tự hỏi khi nào mới ổn', 0.85),
    ROW('sợ ngày mai cũng như hôm nay', 0.9),
    ROW('cảm giác không còn gì để mong chờ', 1.0),
    ROW('không còn động lực tin vào điều tốt', 0.9),
    ROW('lúc nào cũng thấy mệt mỏi trong lòng', 0.85),
    ROW('thấy cuộc sống cứ nặng trĩu', 0.9),
    ROW('không biết mọi thứ có thay đổi không', 0.9),
    ROW('hay nghĩ đến chuyện bỏ cuộc', 1.0),
    ROW('khó đứng dậy sau nhiều chuyện', 0.9),
    ROW('cảm giác thiếu chỗ bấu víu', 0.95),
    ROW('cần ai đó nói mọi thứ sẽ ổn', 0.9),
    ROW('thấy tương lai toàn màu xám', 0.95),
    ROW('cảm giác hụt chân', 0.85),
    ROW('lòng cứ xuống dốc', 0.9),
    ROW('cảm giác không ai hiểu được mình đang trải qua gì', 0.9),
    ROW('tâm trạng rơi tự do', 0.9),
    ROW('không thấy gì để mong chờ phía trước', 1.0),
    ROW('cảm giác bị bỏ lại phía sau', 0.85),
    ROW('thấy tương lai xa vời', 0.85),
    ROW('nỗi buồn khó mà nguôi', 0.9),
    ROW('mọi thứ vượt ngoài tầm kiểm soát', 0.9),
    ROW('tâm trạng xuống đáy', 0.9),
    ROW('cảm giác muốn biến mất cho nhẹ', 1.0)

    ROW('feeling stuck forever', 1.0),
    ROW('can’t see a way out', 1.0),
    ROW('everything feels dark', 0.95),
    ROW('future looks blurry', 0.9),
    ROW('feeling helpless', 0.95),
    ROW('don’t know if things will get better', 0.95),
    ROW('losing trust in myself', 0.9),
    ROW('things keep getting worse', 0.9),
    ROW('emotionally exhausted', 0.85),
    ROW('nothing feels okay anymore', 0.9),
    ROW('can’t imagine things improving', 0.95),
    ROW('feeling weighed down', 0.85),
    ROW('everything feels heavy', 0.9),
    ROW('feeling like giving up', 1.0),
    ROW('can’t hold on anymore', 1.0),
    ROW('running out of strength', 0.9),
    ROW('don’t know how much longer I can keep going', 1.0),
    ROW('feeling overwhelmed', 0.9),
    ROW('future feels empty', 0.9),
    ROW('everything seems pointless lately', 0.95),
    ROW('struggling to stay positive', 0.9),
    ROW('hard to believe things will be okay', 0.95),
    ROW('stuck in a dark place', 1.0),
    ROW('feel like nothing will change', 0.95),
    ROW('lost all sense of direction emotionally', 0.9),
    ROW('feel like I’m drowning', 0.95),
    ROW('can’t find anything to look forward to', 1.0),
    ROW('emotionally drained', 0.85),
    ROW('feeling left behind', 0.85),
    ROW('heart feels heavy', 0.9),
    ROW('don’t know how to get back up', 0.9),
    ROW('everything feels too much', 0.9),
    ROW('having a hard time holding myself together', 0.9),
    ROW('feeling like I’m falling apart', 0.95),
    ROW('don’t see any light ahead', 1.0),
    ROW('wish someone could tell me it’ll be okay', 0.9),
    ROW('future feels too far away', 0.8),
    ROW('feeling lost emotionally', 0.85),
    ROW('hard to keep faith in anything', 0.9),
    ROW('struggling silently', 0.85),
    ROW('everything feels unstable', 0.85),
    ROW('it’s been rough for a long time', 0.9),
    ROW('don’t know how to cope anymore', 0.95),
    ROW('everything feels uncertain in a bad way', 0.9),
    ROW('feeling emotionally cold', 0.8),
    ROW('feeling disconnected from life', 0.9),
    ROW('nothing excites me anymore', 0.85),
    ROW('feeling empty inside', 0.9),
    ROW('feeling like I don’t belong anywhere', 0.85)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='hy_vong'
ON CONFLICT DO NOTHING;

INSERT INTO need_keywords (need_id, keyword, weight, type)
SELECT id, kw, wt, 'keyword'
FROM needs, unnest(
  ARRAY[
    ROW('không biết', 1.0),
    ROW('khó xác định', 0.9),

    ROW('không biết mình cần gì', 0.95),
    ROW('không hiểu cảm xúc của mình', 0.95),
    ROW('thấy khó diễn tả', 0.8),
    ROW('không rõ mình đang sao', 0.9),
    ROW('cảm xúc lẫn lộn', 0.9),
    ROW('tâm trạng mơ hồ', 0.9),
    ROW('thấy hơi kì kì', 0.75),
    ROW('không biết mình muốn gì', 0.9),
    ROW('cảm giác lạ lạ', 0.75),
    ROW('không gọi tên được cảm xúc', 0.9),
    ROW('hơi bối rối về cảm xúc', 0.85),
    ROW('không rõ điều mình thiếu', 0.85),
    ROW('khó hiểu chính mình', 0.9),
    ROW('không biết chuyện gì đang xảy ra bên trong', 0.95),
    ROW('cảm giác mông lung', 0.9),
    ROW('không chắc mình đang buồn hay mệt', 0.85),
    ROW('lòng hơi mơ màng', 0.8),
    ROW('trong người cứ sao sao', 0.8),
    ROW('khó diễn đạt cho ai nghe', 0.85),
    ROW('không biết bắt đầu từ đâu', 0.8),
    ROW('cảm xúc bị rối tung', 0.9),
    ROW('thấy không ổn nhưng không biết vì sao', 0.95),
    ROW('cảm thấy lạc trong cảm xúc', 0.9),
    ROW('tâm trạng trôi nổi', 0.85),
    ROW('khó xác định vấn đề', 0.9),
    ROW('mọi thứ trong đầu hơi lộn xộn', 0.9),
    ROW('không biết chuyện gì khiến mình vậy', 0.9),
    ROW('cảm giác không gọi tên', 0.9),
    ROW('thấy trống trống nhưng không rõ lý do', 0.9),
    ROW('cảm xúc không thẳng hàng', 0.85),
    ROW('đầu óc hơi mù mờ', 0.85),
    ROW('thấy mệt mà không hiểu tại sao', 0.9),
    ROW('cảm giác nửa buồn nửa không', 0.85),
    ROW('tâm trạng khó nắm bắt', 0.9),
    ROW('không chắc điều mình đang tìm', 0.85),
    ROW('không rõ mình cần ai hay cần gì', 0.9),
    ROW('không tìm được từ diễn tả', 0.85),
    ROW('hơi bất ổn trong lòng nhưng không rõ lý do', 0.9),
    ROW('cảm giác lệch nhịp', 0.8),
    ROW('kiểu… không biết nói sao', 0.75),

    ROW('i dont know what i need', 0.95),
    ROW('cant tell what im feeling', 0.95),
    ROW('my emotions feel blurry', 0.9),
    ROW('feeling weird but not sure why', 0.85),
    ROW('something feels off', 0.9),
    ROW('not sure whats wrong', 0.9),
    ROW('cant put it into words', 0.85),
    ROW('mixed feelings', 0.85),
    ROW('confused inside', 0.9),
    ROW('not sure whats going on with me', 0.95),
    ROW('dont know how to describe it', 0.85),
    ROW('emotionally unsure', 0.9),
    ROW('cant name the feeling', 0.9),
    ROW('something is bothering me but i dont know what', 0.95),
    ROW('mood feels undefined', 0.9),
    ROW('emotionally messy', 0.9),
    ROW('my mind feels foggy', 0.85),
    ROW('cant figure myself out', 0.9),
    ROW('feeling off balance', 0.85),
    ROW('cant explain what is happening', 0.85),
    ROW('not exactly sad not exactly okay', 0.85),
    ROW('dont know what im missing', 0.9),
    ROW('vague emotional discomfort', 0.9),
    ROW('not sure what im looking for', 0.85),
    ROW('feeling a bit lost inside', 0.9),
    ROW('something doesnt feel right', 0.9),
    ROW('emotions feel tangled', 0.9),
    ROW('everything feels unclear', 0.9),
    ROW('hard to understand myself', 0.9),
    ROW('feeling unsettled', 0.85),
    ROW('not sure what i want', 0.9),
    ROW('i feel weirdly neutral', 0.8),
    ROW('i dont know what this feeling is', 0.9),
    ROW('hard to tell how i feel', 0.9),
    ROW('just confused emotionally', 0.9),
    ROW('feeling neither good nor bad', 0.8),
    ROW('cant figure out the problem', 0.9),
    ROW('my mind feels unfocused', 0.85),
    ROW('cant define my mood', 0.9),
    ROW('i just feel weird', 0.8)
  ]::text_weight[]
) AS t(kw, wt)
WHERE slug='khong_xac_dinh'
ON CONFLICT DO NOTHING;

-- Links emotion <-> need
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='buon' AND n.slug='ket_noi'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='buon' AND n.slug='duoc_hieu'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='buon' AND n.slug='chap_nhan'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.6 FROM emotions e, needs n WHERE e.slug='buon' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='lo_lang' AND n.slug='kiem_soat'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='lo_lang' AND n.slug='an_toan'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='lo_lang' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.6 FROM emotions e, needs n WHERE e.slug='lo_lang' AND n.slug='hy_vong'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='met_moi' AND n.slug='nghi_ngoi'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='met_moi' AND n.slug='dong_luc'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.6 FROM emotions e, needs n WHERE e.slug='met_moi' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='vui' AND n.slug='hy_vong'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='vui' AND n.slug='tu_ton'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='vui' AND n.slug='cong_nhan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='dong_luc' AND n.slug='dong_luc'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='dong_luc' AND n.slug='y_nghia'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='dong_luc' AND n.slug='hy_vong'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='tuc_gian' AND n.slug='kiem_soat'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='tuc_gian' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='tuc_gian' AND n.slug='duoc_hieu'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.6 FROM emotions e, needs n WHERE e.slug='tuc_gian' AND n.slug='chap_nhan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='toi_loi' AND n.slug='tu_ton'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='toi_loi' AND n.slug='chap_nhan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='boi_roi' AND n.slug='dinh_huong'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='boi_roi' AND n.slug='hy_vong'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.9 FROM emotions e, needs n WHERE e.slug='so_hai' AND n.slug='an_toan'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='so_hai' AND n.slug='kiem_soat'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='so_hai' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.8 FROM emotions e, needs n WHERE e.slug='trung_lap' AND n.slug='binh_on'
ON CONFLICT DO NOTHING;
INSERT INTO emotion_need_links (emotion_id, need_id, relationship_strength)
SELECT e.id, n.id, 0.7 FROM emotions e, needs n WHERE e.slug='trung_lap' AND n.slug='hy_vong'
ON CONFLICT DO NOTHING;

-- Actions

INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('tip_breathing_478', 'Thở sâu 4-7-8', 'Kỹ thuật thở giúp ổn định hệ thần kinh và giảm lo âu', 
   'tip', 1, 1, 2, 'Hít vào 4s, giữ 7s, thở ra 8s. Lặp lại 3 lần.', 
   'Cảm giác thư giãn, nhịp tim giảm', 
   '{"emotion":"anxious"}', '{"emotion":"calm","physiological_state":"relaxed"}', 
   30, 3, 'behavioral'),

  ('tip_grounding_54321', 'Bài tập 5-4-3-2-1', 'Giúp đưa tâm trí về hiện tại bằng cách chú ý giác quan', 
   'tip', 1, 1, 2, 'Nhìn 5 thứ bạn thấy, chạm 4 thứ bạn cảm nhận, nghe 3 âm thanh, ngửi 2 mùi, nếm 1 vị.', 
   'Tăng khả năng hiện diện, giảm lo âu', 
   '{"emotion":"anxious"}', '{"emotion":"grounded"}', 
   120, 3, 'behavioral'),

  ('tip_walk_outdoor', 'Đi bộ nhẹ ngoài trời', 'Vận động nhẹ giúp cải thiện tâm trạng và giảm mệt mỏi', 
   'tip', 1, 1, 3, 'Hãy đi bộ chậm 10-15 phút, chú ý hơi thở và cảnh vật xung quanh.', 
   'Tăng năng lượng, giảm buồn và lo', 
   '{"emotion":"sad"}', '{"emotion":"energized"}', 
   600, 2, 'behavioral');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('question_reframe', 'Tái cấu trúc suy nghĩ', 'Giúp bạn nhìn nhận tình huống từ góc nhìn khác', 
   'question', 2, 2, 3, 'Nếu bạn là bạn thân của mình, bạn sẽ nói gì với chính bạn lúc này?', 
   'Giảm tự chỉ trích, tăng tự hiểu', 
   '{"emotion":"guilty, sad"}', '{"emotion":"understood"}', 
   120, 3, 'cognitive'),

  ('exercise_thought_log', 'Nhật ký suy nghĩ', 'Ghi lại suy nghĩ và cảm xúc để phát hiện mẫu tiêu cực', 
   'exercise', 2, 1, 3, 'Viết ra: Sự kiện - Suy nghĩ - Cảm xúc - Hành vi - Cách thay đổi suy nghĩ.', 
   'Nhận diện mô hình nhận thức tiêu cực', 
   '{"emotion":"confused"}', '{"emotion":"clarity"}', 
   0, 5, 'cognitive'),

  ('question_focus_control', 'Điều bạn kiểm soát', 'Giúp tập trung vào yếu tố có thể thay đổi', 
   'question', 2, 2, 3, 'Hôm nay bạn có thể kiểm soát được điều gì nhỏ nhất?', 
   'Giảm lo âu, tăng cảm giác chủ động', 
   '{"emotion":"anxious"}', '{"emotion":"in_control"}', 
   120, 3, 'cognitive');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('exercise_emotion_journal', 'Nhật ký cảm xúc', 'Ghi lại cảm xúc và nguyên nhân giúp nhận diện bản thân', 
   'exercise', 2, 1, 3, 'Hôm nay bạn cảm thấy thế nào? Hãy viết ra 3 cảm xúc và điều khiến bạn cảm thấy vậy.', 
   'Nhận diện và giải tỏa cảm xúc', 
   '{"emotion":"sad"}', '{"emotion":"relieved"}', 
   0, 5, 'emotional'),

  ('exercise_letter_self', 'Viết thư cho bản thân', 'Thư gửi chính mình giúp biểu lộ cảm xúc an toàn', 
   'exercise', 2, 2, 3, 'Viết cho bản thân: “Mình biết bạn đang cảm thấy..., nhưng mình vẫn ở đây cùng bạn.”', 
   'Tăng tự thương, giảm cô đơn', 
   '{"emotion":"guilty"}', '{"emotion":"accepted"}', 
   0, 3, 'emotional');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('tip_body_scan', 'Body Scan', 'Quan sát cơ thể từ đầu đến chân, nhận biết cảm giác hiện tại', 
   'tip', 2, 1, 3, 'Nhắm mắt, di chuyển sự chú ý từ đầu đến chân, ghi nhận cảm giác mà không phán xét.', 
   'Giảm căng cơ, tăng kết nối thân-tâm', 
   '{"emotion":"tired, anxious"}', '{"emotion":"relaxed"}', 
   300, 3, 'behavioral'),

  ('exercise_selfcare_plan', 'Kế hoạch tự chăm sóc', 'Liệt kê 3 việc nhỏ giúp bạn nạp lại năng lượng', 
   'exercise', 2, 1, 3, 'Hôm nay bạn có thể làm gì để chăm sóc bản thân? (ngủ đủ, ăn ngon, nghỉ ngơi...)', 
   'Tăng ý thức tự chăm sóc, giảm kiệt sức', 
   '{"emotion":"tired"}', '{"emotion":"restored"}', 
   0, 3, 'behavioral');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('tip_message_friend', 'Nhắn tin với bạn thân', 'Gợi ý kết nối xã hội giúp giảm cô đơn', 
   'tip', 2, 1, 3, 'Gửi tin nhắn cho ai đó mà bạn tin tưởng hoặc nhớ đến.', 
   'Cảm giác được kết nối, giảm cô lập', 
   '{"emotion":"sad"}', '{"emotion":"connected"}', 
   600, 2, 'social'),

  ('question_social_support', 'Ai đang ở bên bạn?', 'Nhận diện nguồn hỗ trợ xã hội hiện có', 
   'question', 2, 1, 2, 'Ai là người bạn có thể chia sẻ hoặc nhờ giúp đỡ hôm nay?', 
   'Tăng cảm giác an toàn, giảm cô đơn', 
   '{"emotion":"sad"}', '{"emotion":"supported"}', 
   180, 3, 'social');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('info_affirmation', 'Khẳng định tích cực', 'Câu nói tự khích lệ giúp tăng động lực', 
   'info', 1, 1, 3, '“Mình đang cố gắng hết sức, và điều đó đủ tốt rồi.”', 
   'Tăng tự tin và lòng nhân ái', 
   '{"emotion":"tired, sad"}', '{"emotion":"motivated"}', 
   60, 5, 'motivational'),

  ('question_value_check', 'Xác định giá trị cá nhân', 'Giúp tìm lại định hướng và mục tiêu', 
   'question', 3, 2, 3, 'Điều gì quan trọng nhất với bạn hiện tại, và bạn có thể làm gì nhỏ để tiến gần hơn?', 
   'Tăng định hướng và ý nghĩa sống', 
   '{"emotion":"confused"}', '{"emotion":"purposeful"}', 
   120, 3, 'motivational');


INSERT INTO actions (slug, name, description, type, level, stage_min, stage_max,
  prompt_template, expected_outcomes, preconditions, postconditions, cooldown_seconds, max_repeats, domain)
VALUES
  ('handoff_contact_support', 'Liên hệ hỗ trợ', 'Gợi ý người dùng tìm hỗ trợ an toàn', 
   'handoff', 3, 2, 3, 'Bạn có thể gọi cho người thân hoặc c\huyên gia khi thấy quá tải.', 
   'Tăng cảm giác an toàn và được giúp đỡ', 
   '{"emotion":"fearful"}', '{"emotion":"safe"}', 
   0, 10, 'safety'),

  ('handoff_hotline', 'Đường dây nóng', 'Cung cấp thông tin liên hệ khẩn cấp khi cần thiết', 
   'handoff', 4, 3, 3, 'Nếu bạn cần, hãy liên hệ 111 hoặc 1900 6233 để được hỗ trợ ngay.', 
   'Đảm bảo an toàn tức thì', 
   '{"emotion":"fearful"}', '{"emotion":"safe"}', 
   0, 1, 'safety');
   
-- Action patterns
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('thở', 1.0),
  ROW('hít thở', 0.9),
  ROW('lo âu', 0.8),
  ROW('căng thẳng', 0.8),
  ROW('anxious', 0.7)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy thư giãn', 1.0),
  ROW('bớt căng thẳng', 0.9),
  ROW('đỡ hơn rồi', 0.9),
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn căng thẳng', 1.0),
  ROW('không bớt lo', 0.9),
  ROW('không đỡ chút nào', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn đã thử thở thật sâu chưa', 0.8),
  ROW('cảm thấy khá hơn không', 1.0),
  ROW('bạn thấy dễ chịu hơn chưa', 1.0),
  ROW('muốn thử thêm vài lần nữa không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

---------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('hiện tại', 0.8),
  ROW('tập trung', 0.9),
  ROW('loạn', 0.8),
  ROW('mất kiểm soát', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('ổn định lại', 1.0),
  ROW('bình tĩnh hơn', 0.9),
  ROW('bớt căng thẳng', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn hoảng', 0.9),
  ROW('chưa tập trung được', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('có thể thử mô tả 5 điều bạn thấy xung quanh không', 1.0),
  ROW('cảm thấy dễ chịu hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('đi bộ', 1.0),
  ROW('ra ngoài', 0.9),
  ROW('vận động', 0.8),
  ROW('không khí', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('dễ chịu hơn', 1.0),
  ROW('tươi tỉnh', 0.9),
  ROW('thoải mái hơn', 1.0),
  ROW('bớt căng thẳng', 0.9),
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn buồn', 0.9),
  ROW('không thấy đỡ', 0.8),
  ROW('còn căng thẳng', 0.8),
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('thấy dễ chịu hơn chưa', 1.0),
  ROW('đi dạo bao lâu rồi', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

---------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('nghĩ theo cách khác', 1.0),
  ROW('góc nhìn', 0.9),
  ROW('nhìn nhận lại', 1.0),
  ROW('tích cực hơn', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_reframe'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('đúng là mình nhìn lệch hướng', 1.0),
  ROW('thấy nhẹ lòng hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_reframe'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn tiêu cực', 0.9),
  ROW('không nghĩ khác được', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_reframe'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn có nhận ra điều gì mới không', 1.0),
  ROW('muốn thử nghĩ theo hướng khác nữa không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_reframe'
ON CONFLICT DO NOTHING;

---------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('nhật ký suy nghĩ', 1.0),
  ROW('ghi lại suy nghĩ', 0.9),
  ROW('thought log', 0.9),
  ROW('viết ra cảm xúc', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('hiểu rõ hơn', 1.0),
  ROW('nhẹ lòng hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('viết mà vẫn rối', 0.9),
  ROW('không giúp được gì', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn có nhận ra mẫu suy nghĩ nào không', 1.0),
  ROW('muốn ghi thêm điều gì nữa không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

----------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('mất tập trung', 1.0),
  ROW('không thể tập trung', 0.9),
  ROW('rối trí', 0.8),
  ROW('khó chú ý', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('tập trung hơn', 1.0),
  ROW('đỡ rối trí', 0.9),
  ROW('cảm thấy kiểm soát được', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn xao nhãng', 0.9),
  ROW('không kiểm soát được', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn có muốn thử lại cách tập trung khác không', 1.0),
  ROW('có dễ chịu hơn chút nào không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

---------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('nhật ký cảm xúc', 1.0),
  ROW('ghi lại cảm xúc', 0.9),
  ROW('viết cảm xúc', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('nhận ra cảm xúc', 1.0),
  ROW('hiểu cảm xúc hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không biết ghi gì', 0.9),
  ROW('vẫn bối rối', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử viết thêm điều gì không', 1.0),
  ROW('cảm thấy nhẹ nhõm hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

-------------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('viết thư cho bản thân', 1.0),
  ROW('thư tự an ủi', 0.9),
  ROW('nhắn nhủ chính mình', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_letter_self'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy an ủi', 1.0),
  ROW('nhẹ nhõm hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_letter_self'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không biết viết gì', 0.9),
  ROW('vẫn buồn', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_letter_self'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử viết tiếp không', 1.0),
  ROW('cảm thấy khá hơn chút nào chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_letter_self'
ON CONFLICT DO NOTHING;
---------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('quan sát cơ thể', 1.0),
  ROW('body scan', 0.9),
  ROW('cảm nhận cơ thể', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_body_scan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('thư giãn cơ thể', 1.0),
  ROW('cảm thấy nhẹ nhõm', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_body_scan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không thư giãn được', 0.9),
  ROW('vẫn căng thẳng', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_body_scan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử lại một lần nữa không', 1.0),
  ROW('có cảm thấy nhẹ nhõm hơn không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_body_scan'
ON CONFLICT DO NOTHING;

--------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('lập kế hoạch tự chăm sóc', 1.0),
  ROW('selfcare plan', 0.9),
  ROW('lịch chăm sóc bản thân', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('thực hiện được kế hoạch', 1.0),
  ROW('cảm thấy tự chăm sóc hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không hoàn thành kế hoạch', 0.9),
  ROW('vẫn chưa chăm sóc bản thân', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử điều chỉnh kế hoạch không', 1.0),
  ROW('có dễ chịu hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('nhắn tin bạn bè', 1.0),
  ROW('gọi bạn', 0.9),
  ROW('chia sẻ với bạn bè', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy được an ủi', 1.0),
  ROW('nhẹ nhõm hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không muốn chia sẻ', 0.9),
  ROW('vẫn cô đơn', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn có muốn thử nhắn thêm không', 1.0),
  ROW('cảm thấy khá hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;

----------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('tìm hỗ trợ', 1.0),
  ROW('chia sẻ với người khác', 0.9),
  ROW('nhờ giúp đỡ', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_social_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy được lắng nghe', 1.0),
  ROW('hỗ trợ hữu ích', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_social_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không nhận được giúp đỡ', 0.9),
  ROW('vẫn cô đơn', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_social_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử tìm ai khác không', 1.0),
  ROW('có ai để chia sẻ chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_social_support'
ON CONFLICT DO NOTHING;

----------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('khẳng định tích cực', 1.0),
  ROW('affirmation', 0.9),
  ROW('câu nói tích cực', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy tích cực', 1.0),
  ROW('được khích lệ', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không cảm thấy tốt hơn', 0.9),
  ROW('vẫn buồn', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn nghe thêm câu khẳng định khác không', 1.0),
  ROW('cảm thấy khá hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

-------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('giá trị bản thân', 1.0),
  ROW('tự đánh giá', 0.9),
  ROW('question value', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_value_check'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('nhận ra giá trị', 1.0),
  ROW('cảm thấy tự tin hơn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_value_check'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('vẫn nghi ngờ bản thân', 0.9),
  ROW('không cảm thấy giá trị', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_value_check'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử kiểm tra lại không', 1.0),
  ROW('có thấy khá hơn không', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='question_value_check'
ON CONFLICT DO NOTHING;

--------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('cần giúp đỡ', 1.0),
  ROW('hỗ trợ ngay', 0.9),
  ROW('liên hệ người thân', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('cảm thấy an toàn', 1.0),
  ROW('được hỗ trợ', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không nhận được hỗ trợ', 0.9),
  ROW('vẫn lo lắng', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('muốn thử gọi lại không', 1.0),
  ROW('có cảm thấy ổn hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;

--------
INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'keyword', 'trigger', wt
FROM actions a,
unnest(ARRAY[
  ROW('hotline', 1.0),
  ROW('số điện thoại hỗ trợ', 0.9),
  ROW('liên hệ chuyên gia', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_hotline'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'success', wt
FROM actions a,
unnest(ARRAY[
  ROW('được giúp đỡ', 1.0),
  ROW('cảm thấy an toàn', 0.9)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_hotline'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'failure', wt
FROM actions a,
unnest(ARRAY[
  ROW('không kết nối được', 0.9),
  ROW('vẫn lo lắng', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_hotline'
ON CONFLICT DO NOTHING;

INSERT INTO action_patterns (action_id, pattern, type, direction, weight)
SELECT a.id, kw, 'semantic_intent', 'followup', wt
FROM actions a,
unnest(ARRAY[
  ROW('bạn có muốn thử gọi lại không', 1.0),
  ROW('cảm thấy ổn hơn chưa', 0.8)
]::text_weight[]) AS t(kw text, wt numeric)
WHERE a.slug='handoff_hotline'
ON CONFLICT DO NOTHING;



-- Emotion+Need -> Actions map

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='buon'
  AND n.slug='nghi_ngoi'
  AND a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='buon'
  AND n.slug='duoc_hieu'
  AND a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='buon'
  AND n.slug='ket_noi'
  AND a.slug='question_social_support'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='buon'
  AND n.slug='ket_noi'
  AND a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;
---------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='lo_lang'
  AND n.slug='nghi_ngoi'
  AND a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='lo_lang'
  AND n.slug='binh_on'
  AND a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='lo_lang'
  AND n.slug='ket_noi'
  AND a.slug='question_social_support'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='lo_lang'
  AND n.slug='binh_on'
  AND a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

-------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='met_moi'
  AND n.slug='dong_luc'
  AND a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='met_moi'
  AND n.slug='kiem_soat'
  AND a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='met_moi'
  AND n.slug='ket_noi'
  AND a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;
----------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.7, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='vui'
  AND n.slug='hy_vong'
  AND a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.7, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='vui'
  AND n.slug='cong_nhan'
  AND a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

--------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='co_dong_luc'
  AND n.slug='cong_nhan'
  AND a.slug='exercise_thought_log'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='co_dong_luc'
  AND n.slug='hy_vong'
  AND a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='co_dong_luc'
  AND n.slug='hy_vong'
  AND a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;
--------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='tuc_gian'
  AND n.slug='binh_on'
  AND a.slug='tip_breathing_478'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='tuc_gian'
  AND n.slug='binh_on'
  AND a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='tuc_gian'
  AND n.slug='binh_on'
  AND a.slug='tip_body_scan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='tuc_gian'
  AND n.slug='binh_on'
  AND a.slug='tip_walk_outdoor'
ON CONFLICT DO NOTHING;

------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='toi_loi'
  AND n.slug='chap_nhan'
  AND a.slug='exercise_letter_self'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='toi_loi'
  AND n.slug='duoc_hieu'
  AND a.slug='question_reframe'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 2, 3
FROM emotions e, needs n, actions a
WHERE e.slug='toi_loi'
  AND n.slug='duoc_hieu'
  AND a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;
------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='boi_roi'
  AND n.slug='kiem_soat'
  AND a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='boi_roi'
  AND n.slug='dinh_huong'
  AND a.slug='question_focus_control'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 3
FROM emotions e, needs n, actions a
WHERE e.slug='boi_roi'
  AND n.slug='dinh_huong'
  AND a.slug='question_value_check'
ON CONFLICT DO NOTHING;

--------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 1.0, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='so_hai'
  AND n.slug='binh_on'
  AND a.slug='tip_grounding_54321'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='so_hai'
  AND n.slug='binh_on'
  AND a.slug='exercise_emotion_journal'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='so_hai'
  AND n.slug='an_toan'
  AND a.slug='handoff_contact_support'
ON CONFLICT DO NOTHING;

--------
INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.8, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='trung_lap'
  AND n.slug='hy_vong'
  AND a.slug='info_affirmation'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='trung_lap'
  AND n.slug='dinh_huong'
  AND a.slug='exercise_selfcare_plan'
ON CONFLICT DO NOTHING;

INSERT INTO emotion_need_action_map (emotion_id, need_id, action_id, min_confidence, stage_min, stage_max)
SELECT e.id, n.id, a.id, 0.9, 1, 2
FROM emotions e, needs n, actions a
WHERE e.slug='trung_lap'
  AND n.slug='ket_noi'
  AND a.slug='tip_message_friend'
ON CONFLICT DO NOTHING;