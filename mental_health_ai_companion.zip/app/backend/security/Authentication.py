# app/security/token.py
from datetime import datetime, timedelta
from jose import JWTError, jwt
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from config.database import get_db
from backend.models import UserModel
from backend.response.AuthResponse import TokenData

SECRET_KEY = "yoursecretkey"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES =  30

def create_access_token(data: dict, expires_delta: timedelta = None):
    print("start create token")
    to_encode = data.copy()
    print(to_encode)
    if expires_delta is None:
        print(123)
        expires_delta = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    print(f"expires_delta {expires_delta}")
    expire = datetime.utcnow() + expires_delta
    print(f"expire {expire}")
    to_encode.update({"exp": expire})
    print("update expire")
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

security = HTTPBearer()
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    """Get current authenticated user"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        user_id: int = payload.get("user_id")
        if username is None or user_id is None:
            raise credentials_exception
        token_data = TokenData(username=username, user_id=user_id)
    except JWTError:
        raise credentials_exception
    
    user = db.query(UserModel).filter(UserModel.id == token_data.user_id).first()
    if user is None:
        raise credentials_exception
    return user